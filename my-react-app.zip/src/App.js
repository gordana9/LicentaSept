import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './Components/Login';
import Main from './Components/Main';
import SignUp from './Components/SignUp'; // Asigură-te că denumirea este corectă, inclusiv majusculele
import Medic from './Components/Medic';
import Pacient from './Components/Pacient';
import AdminPage from './Components/AdminPage'; 
import ListaPreturi from './Components/ListaPreturi'; // Importă componenta ListaPreturi
import DespreNoi from './Components/DespreNoi'; // Importă componenta DespreNoi
import CentreCAS from './Components/CentreCAS'; // Importă componenta CentreCAS
import CentreRecoltare from './Components/CentreRecoltare';
import Spitale from './Components/Spitale'; // Importă componentul Spitale
import Programare from './Components/Programare';
import ProgramariPacient from './Components/ProgramariPacient';
import MedicPage from './Components/MedicPage';
import Laborator from './Components/Laborator';

function App() {
    return (
        <Router>
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/signup" element={<SignUp />} />
                <Route path="/main" element={<Main />} />
                <Route path="/medic" element={<Medic />} />
                <Route path="/pacient" element={<Pacient />} />
                <Route path="/admin" element={<AdminPage />} /> 
                <Route path="/listapreturi" element={<ListaPreturi />} /> {/* Adaugă ruta pentru ListaPreturi */}
                <Route path="/despre-noi" element={<DespreNoi />} /> {/* Adaugă ruta pentru DespreNoi */}
                <Route path="/centre-cas" element={<CentreCAS />} /> {/* Adaugă ruta pentru CentreCAS */}
                <Route path="/centre-recoltare" element={<CentreRecoltare />} />
                <Route path="/spitale" element={<Spitale />} />
                <Route path="/programare" element={<Programare />} />
                <Route path="/programari" element={<ProgramariPacient />} />
                <Route path="/medici" element={<MedicPage />} />
                <Route path="/laborator" element={<Laborator />} />
                <Route path="/" element={<Login />} />
            </Routes>
        </Router>
    );
}

export default App;
