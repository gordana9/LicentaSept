import React, { useEffect, useState } from 'react';
import './ListaPreturi.css';
import logo3 from '../assets/logo4.png'; // Importă imaginea logo

const ListaPreturi = () => {
    const [patientName, setPatientName] = useState('');
    const [selectedAnalize, setSelectedAnalize] = useState([]);
    const [uploadedFiles, setUploadedFiles] = useState([]);
    const [showResults, setShowResults] = useState(false);

    // Array-ul cu date despre analize
    const analize = [
        { numar: 1, nume: 'Glucoză', pret: 25, durata: '24 ore' },
        { numar: 2, nume: 'Hemoleucogramă completă', pret: 40, durata: '24 ore' },
        { numar: 3, nume: 'Colesterol total', pret: 30, durata: '24 ore' },
        { numar: 4, nume: 'Trigliceride', pret: 35, durata: '24 ore' },
        { numar: 5, nume: 'Uree sanguină', pret: 25, durata: '24 ore' },
        { numar: 6, nume: 'Creatinină', pret: 30, durata: '24 ore' },
        { numar: 7, nume: 'Acid uric', pret: 35, durata: '24 ore' },
        { numar: 8, nume: 'TGO (AST)', pret: 30, durata: '24 ore' },
        { numar: 9, nume: 'TGP (ALT)', pret: 30, durata: '24 ore' },
        { numar: 10, nume: 'Bilirubină totală', pret: 40, durata: '24 ore' },
        { numar: 11, nume: 'Calcium seric', pret: 50, durata: '24 ore' },
        { numar: 12, nume: 'Ionogramă sanguină', pret: 70, durata: '48 ore' },
        { numar: 13, nume: 'Profil lipidic complet', pret: 80, durata: '24 ore' },
        { numar: 14, nume: 'Proteina C reactivă (PCR)', pret: 50, durata: '24 ore' },
        { numar: 15, nume: 'TSH', pret: 70, durata: '48 ore' },
        { numar: 16, nume: 'FT4 (Tiroxina liberă)', pret: 75, durata: '48 ore' },
        { numar: 17, nume: 'Testosterone total', pret: 100, durata: '72 ore' },
        { numar: 18, nume: 'Estradiol', pret: 100, durata: '72 ore' },
        { numar: 19, nume: 'Vitamina D', pret: 150, durata: '5 zile' },
        { numar: 20, nume: 'Vitamina B12', pret: 150, durata: '5 zile' },
        { numar: 21, nume: 'Anticorpi anti-TPO', pret: 120, durata: '72 ore' },
        { numar: 22, nume: 'Anticorpi anti-tireoglobulină', pret: 120, durata: '72 ore' },
        { numar: 23, nume: 'Ferritină', pret: 80, durata: '48 ore' },
        { numar: 24, nume: 'Fibrinogen', pret: 70, durata: '48 ore' },
        { numar: 25, nume: 'D-dimeri', pret: 100, durata: '48 ore' },
        { numar: 26, nume: 'HbA1c (Hemoglobină glicozilată)', pret: 60, durata: '48 ore' },
        { numar: 27, nume: 'HIV (Anticorpi)', pret: 90, durata: '72 ore' },
        { numar: 28, nume: 'Hepatita B (Antigen HBsAg)', pret: 60, durata: '48 ore' },
        { numar: 29, nume: 'Hepatita C (Anticorpi anti-HCV)', pret: 80, durata: '48 ore' },
        { numar: 30, nume: 'Test Papanicolau', pret: 100, durata: '3 zile' },
        { numar: 31, nume: 'HPV ADN test', pret: 200, durata: '5 zile' },
        { numar: 32, nume: 'Ecografia abdominală', pret: 150, durata: '30 minute' },
        { numar: 33, nume: 'CT abdominal', pret: 400, durata: '1 oră' },
        { numar: 34, nume: 'RMN cerebral', pret: 500, durata: '1 oră' },
        { numar: 35, nume: 'Test de toleranță la glucoză', pret: 70, durata: '2 ore' },
        { numar: 36, nume: 'Sideremie', pret: 40, durata: '24 ore' },
        { numar: 37, nume: 'Examen coproparazitologic', pret: 25, durata: '24 ore' },
        { numar: 38, nume: 'Cultura de urină cu antibiogramă', pret: 70, durata: '72 ore' },
        { numar: 39, nume: 'Spirometrie', pret: 100, durata: '30 minute' },
        { numar: 40, nume: 'Electrocardiogramă (EKG)', pret: 50, durata: '15 minute' }
    ];

    useEffect(() => {
        const patientNameFromStorage = localStorage.getItem('username');
        const userID = localStorage.getItem('userID'); // Obține userID-ul utilizatorului curent

        if (patientNameFromStorage) {
            setPatientName(patientNameFromStorage);
        }

        // Recuperare și filtrare fișiere încărcate pe baza userID-ului
        const storedFiles = JSON.parse(localStorage.getItem('uploadedFiles')) || [];
        const filteredFiles = storedFiles.filter(file => file.userID === userID); // Afișează doar fișierele utilizatorului curent
        setUploadedFiles(filteredFiles);
    }, []);

    const handleCheckboxChange = (numar, nume, pret) => {
        setSelectedAnalize(prevSelectedAnalize => {
            if (prevSelectedAnalize.some(analiza => analiza.numar === numar)) {
                return prevSelectedAnalize.filter(analiza => analiza.numar !== numar);
            } else {
                return [...prevSelectedAnalize, { numar, nume, pret }];
            }
        });
    };

    const totalPret = selectedAnalize.reduce((total, analiza) => total + analiza.pret, 0);

    const handleSubmit = () => {
        const userID = localStorage.getItem('userID'); // Obține userID-ul utilizatorului curent
        const newEntry = {
            userID, // Adaugă userID pentru a lega cererea de utilizator
            patientName,
            selectedAnalize
        };

        let existingData = JSON.parse(localStorage.getItem('adminData')) || [];
        existingData.push(newEntry);
        localStorage.setItem('adminData', JSON.stringify(existingData));

        alert('Informațiile au fost trimise!');
    };

    const handleToggleResults = () => {
        setShowResults(!showResults);
    };

    return (
        <div className="lista-preturi-container">
            <div className="navbar">
                <img src={logo3} alt="Clinic Logo" className="logo3" />
                <div className="nav-links">
                    <a href="/pacient">HOME</a>
                    <a href="#" className="active-link">ANALIZE ȘI PREȚURI</a>
                    <a href="/programari">PROGRAMĂRI</a>
                    <div className="dropdown">
                        <button className="dropbtn">LOCAȚII</button>
                        <div className="dropdown-content">
                            <a href="/spitale">Spitale</a>
                            <a href="/centre-recoltare">Centre de recoltare</a>
                        </div>
                    </div>
                    <a href="/despre-noi">DESPRE NOI</a>
                    <a href="#">CONTACT</a>
                </div>
                <div className="right-section">
                    <button className="solicita-button">+ Solicita programare</button>
                    <span className="patient-name">{patientName}</span>
                </div>
            </div>
            <div className="content">
                <h2>Lista de prețuri pentru analize medicale</h2>
                <table>
                    <thead>
                        <tr>
                            <th>NR.</th>
                            <th>Denumire analiză</th>
                            <th>Pret (Lei)</th>
                            <th>Durata de execuție</th>
                            <th>Selectează</th>
                        </tr>
                    </thead>
                    <tbody>
                        {analize.map(analiza => (
                            <tr key={analiza.numar}>
                                <td>{analiza.numar}</td>
                                <td>{analiza.nume}</td>
                                <td>{analiza.pret} Lei</td>
                                <td>{analiza.durata}</td>
                                <td>
                                    <input 
                                        type="checkbox" 
                                        onChange={() => handleCheckboxChange(analiza.numar, analiza.nume, analiza.pret)} 
                                    />
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                <div className="total">
                    <h3>Total: {totalPret} Lei</h3>
                    <button onClick={handleSubmit} className="trimite-button">Trimite</button>
                </div>
                <div className="results">
                    <button onClick={handleToggleResults} className="results-button">Rezultate analize</button>
                    {showResults && (
                        <div className="uploaded-files">
                            {uploadedFiles.length === 0 ? (
                                <p>Nu există rezultate încărcate.</p>
                            ) : (
                                uploadedFiles.map((file, index) => (
                                    <div key={index} className="file-entry">
                                        <h4>{file.name}</h4>
                                        <iframe
                                            src={file.url}
                                            width="600"
                                            height="500"
                                            title={`PDF-ul ${file.name}`}
                                        ></iframe>
                                    </div>
                                ))
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ListaPreturi;
