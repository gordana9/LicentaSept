import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import './Programare.css';
import logo3 from '../assets/logo4.png'; // Asigură-te că calea către logo este corectă

const Programare = () => {
    const [patientName, setPatientName] = useState(localStorage.getItem('username') || '');
    const [selectedSpecialization, setSelectedSpecialization] = useState('');
    const [selectedDoctor, setSelectedDoctor] = useState('');
    const [selectedDate, setSelectedDate] = useState(null);
    const [selectedTime, setSelectedTime] = useState('');
    const [availableTimeSlots, setAvailableTimeSlots] = useState([]);
    const navigate = useNavigate();

    const specializations = [
        "Alergologie", "Cardiologie", "Dermatologie", "Ginecologie",
        "Neurologie", "Oftalmologie", "ORL", "Pediatrie", "Radiologie", "Stomatologie",
    ];

    const doctors = [
        { id: 1, nume: "Ionescu", prenume: "Andrei", specializare: "Cardiologie" },
        { id: 2, nume: "Tunei", prenume: "Andreea", specializare: "Dermatologie" },
        { id: 6, nume: "Negoitescu", prenume: "Dan", specializare: "Dermatologie" },
        { id: 7, nume: "Ionescu", prenume: "Maria", specializare: "Cardiologie" },
        { id: 8, nume: "Popescu", prenume: "Alexandru", specializare: "Neurologie" },
        { id: 9, nume: "Vasilescu", prenume: "Elena", specializare: "Ginecologie" },
        { id: 10, nume: "Stanescu", prenume: "Mihai", specializare: "Radiologie" },
        { id: 11, nume: "Dumitrescu", prenume: "Andreea", specializare: "Stomatologie" },
        { id: 12, nume: "Georgescu", prenume: "Ioana", specializare: "Pediatrie" },
        { id: 13, nume: "Marinescu", prenume: "Adrian", specializare: "ORL" },
        { id: 14, nume: "Constantinescu", prenume: "Sorin", specializare: "Oftalmologie" },
        { id: 15, nume: "Stoicescu", prenume: "Diana", specializare: "Alergologie" },
        { id: 16, nume: "Radu", prenume: "Cristian", specializare: "Dermatologie" },
        { id: 17, nume: "Petrescu", prenume: "Gabriela", specializare: "Cardiologie" },
        { id: 18, nume: "Munteanu", prenume: "Anca", specializare: "Neurologie" },
        { id: 19, nume: "Iliescu", prenume: "Florin", specializare: "Ginecologie" },
        { id: 20, nume: "Tudorache", prenume: "Laura", specializare: "Radiologie" },
    ];

    useEffect(() => {
        if (selectedDate && selectedDoctor) {
            const storedAppointments = JSON.parse(localStorage.getItem('appointments')) || [];
            const reservedTimes = storedAppointments
                .filter(app => app.doctorName === selectedDoctor && app.date === selectedDate.toLocaleDateString() && app.status === 'Approved')
                .map(app => app.time);

            setAvailableTimeSlots(getTimeSlots(selectedDate.getDay()).filter(time => !reservedTimes.includes(time)));
        }
    }, [selectedDate, selectedDoctor]);

    const handleSpecializationChange = (event) => {
        setSelectedSpecialization(event.target.value);
        setSelectedDoctor(''); // Resetăm doctorul selectat când se schimbă specializarea
    };

    const filteredDoctors = doctors.filter(doctor => doctor.specializare === selectedSpecialization);

    const handleDoctorChange = (event) => {
        setSelectedDoctor(event.target.value);
    };

    const handleSubmit = () => {
        if (selectedSpecialization && selectedDoctor && selectedDate && selectedTime) {
            const doctor = doctors.find(doc => `${doc.nume} ${doc.prenume}` === selectedDoctor);
            if (doctor) {
                const appointments = JSON.parse(localStorage.getItem('appointments')) || [];
                appointments.push({
                    patientName,
                    specialization: selectedSpecialization,
                    doctorName: `${doctor.nume} ${doctor.prenume}`,
                    date: selectedDate.toLocaleDateString(),
                    time: selectedTime,
                    status: 'Pending'
                });
                localStorage.setItem('appointments', JSON.stringify(appointments));
                alert('Programarea a fost trimisă doctorului.');
                navigate('/programari');
            }
        } else {
            alert('Vă rugăm să completați toate câmpurile.');
        }
    };

    const isWeekday = date => {
        const day = date.getDay();
        const today = new Date();
        return day !== 0 && day !== 6 && date >= today;
    };

    const getTimeSlots = (day) => {
        const hours = [];
        if (day === 1 || day === 3) { // luni/miercuri
            for (let i = 8; i < 14; i++) {
                hours.push(`${i}:00`);
                hours.push(`${i}:30`);
            }
        } else if (day === 2 || day === 4) { // marti/joi
            for (let i = 14; i < 20; i++) {
                hours.push(`${i}:00`);
                hours.push(`${i}:30`);
            }
        } else if (day === 5) { // vineri
            for (let i = 10; i < 14; i++) {
                hours.push(`${i}:00`);
                hours.push(`${i}:30`);
            }
        }
        return hours;
    };
    return (
        <div className="pacient-container">
            <div className="navbar">
                <img src={logo3} alt="Clinic Logo" className="logo3" />
                <div className="nav-links">
                    <button onClick={() => navigate('/pacient', { replace: true })}>HOME</button>
                    <button onClick={() => navigate('/listapreturi')}>ANALIZE ȘI PREȚURI</button>
                    <button onClick={() => navigate('/programari')}>PROGRAMĂRI</button>
                    <div className="dropdown">
                        <button className="dropbtn">LOCAȚII</button>
                        <div className="dropdown-content">
                            <button onClick={() => navigate('/spitale')}>Spitale</button>
                            {/* <button onClick={() => navigate('/centre-cas')}>Centre CAS</button> */}
                            <button onClick={() => navigate('/centre-recoltare')}>Centre de recoltare</button>
                        </div>
                    </div>
                    <button onClick={() => navigate('/despre-noi')}>DESPRE NOI</button>
                    <div className="dropdown">
                        <button className="dropbtn">CONTACT</button>
                        <div className="dropdown-content">
                            <span>(021) 7302</span>
                        </div>
                    </div>
                </div>
                <div className="right-section">
                    <button onClick={() => navigate('/programare')} className="solicita-button">+ Solicita programare</button>
                    <span className="patient-name">{patientName}</span>
                </div>
            </div>
            <div className="left-section">
                <h1>Programare Online</h1>
                <p>Aici puteți solicita o programare pentru serviciile noastre de oriunde vă aflați, fără telefon și fără vizită în unitățile ClinicMed.</p>
            </div>
            <div className="programare-online">
                <h2>Detaliile programării</h2>
                <div className="form-group">
                    <label htmlFor="patientName">Nume Pacient:</label>
                    <input
                        type="text"
                        id="patientName"
                        value={patientName}
                        onChange={(e) => setPatientName(e.target.value)}
                        disabled
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="specialization">Specialitate:</label>
                    <select id="specialization" value={selectedSpecialization} onChange={handleSpecializationChange}>
                        <option value="">Selectați o specialitate</option>
                        {specializations.map((specialization, index) => (
                            <option key={index} value={specialization}>{specialization}</option>
                        ))}
                    </select>
                </div>
                <div className="form-group">
                    <label htmlFor="doctor">Doctori disponibili:</label>
                    <select id="doctor" value={selectedDoctor} onChange={handleDoctorChange} disabled={!selectedSpecialization}>
                        <option value="">Selectați un doctor</option>
                        {filteredDoctors.map(doctor => (
                            <option key={doctor.id} value={`${doctor.nume} ${doctor.prenume}`}>
                                {doctor.nume} {doctor.prenume}
                            </option>
                        ))}
                    </select>
                </div>
                <div className="form-group">
                    <label htmlFor="datepicker">Data programării:</label>
                    <DatePicker
                        id="datepicker"
                        selected={selectedDate}
                        onChange={(date) => {
                            setSelectedDate(date);
                            setSelectedTime('');
                        }}
                        dateFormat="dd/MM/yyyy"
                        placeholderText="Selectați o dată"
                        filterDate={isWeekday}
                        minDate={new Date()}
                    />
                </div>
                {selectedDate && (
                    <div className="form-group">
                        <label htmlFor="timepicker">Ora programării:</label>
                        <select id="timepicker" value={selectedTime} onChange={(e) => setSelectedTime(e.target.value)}>
                            <option value="">Selectați o oră</option>
                            {availableTimeSlots.map((time, index) => (
                                <option key={index} value={time}>{time}</option>
                            ))}
                        </select>
                    </div>
                )}
                <button className="solicita-button1" onClick={handleSubmit}>
                    Solicită Programare
                </button>
            </div>
        </div>
    );
};

export default Programare;
