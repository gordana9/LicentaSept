import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Spitale.css'; // Importă stilurile specifice pentru Spitale
import logo3 from '../assets/logo4.png'; // Importă imaginea logo
import drImage from '../assets/dr.png'; // Importă imaginea dr.png

const Spitale = () => {
    const [patientName, setPatientName] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const patientNameFromStorage = localStorage.getItem('username');
        if (patientNameFromStorage) {
            setPatientName(patientNameFromStorage);
        }
    }, []);

    const handleLogout = () => {
        localStorage.removeItem('username');
        localStorage.removeItem('userId');
        navigate('/login');
    };

    return (
        <div className="pacient-container">
            <div className="navbar">
                <img src={logo3} alt="Clinic Logo" className="logo3" />
                <div className="nav-links">
                <a href="#" onClick={() => navigate('/pacient', { replace: true })}>HOME</a>
                    <button onClick={() => navigate('/listapreturi')} style={{ color: 'white' }}>ANALIZE ȘI PREȚURI</button>
                    <button onClick={() => navigate('/programari')}>PROGRAMĂRI</button>
                    
                    <div className="dropdown">
                        <button className="dropbtn">LOCAȚII</button>
                        <div className="dropdown-content">
                            <button onClick={() => navigate('/spitale')}>Spitale</button>
                            {/* <button onClick={() => navigate('/centre-cas')}>Centre CAS</button> */}
                            <button onClick={() => navigate('/centre-recoltare')}>Centre de recoltare</button>
                        </div>
                    </div>
                    <button onClick={() => navigate('/despre-noi')}>DESPRE NOI</button>
                    <div className="dropdown">
                        <a href="#">CONTACT</a>
                        <div className="dropdown-content">
                            (021) 7302
                        </div>
                    </div>
                </div>
                <div className="right-section">
                    <button onClick={() => navigate('/programare')} className="solicita-button">+ Solicita programare</button>
                    <span className="patient-name">{patientName}</span> {/* Adaugă acest span */}
                    {/* <button className="logout-button" onClick={handleLogout}>LOG-OUT</button> */}
                </div>
            </div>
            <div className="welcome-section">
                <h1></h1>
            </div>
            <div className="spitale-content">
                <div className="table-container">
                    <table className="spitale-table">
                        <thead>
                            <tr>
                                <th>Oraș</th>
                                <th>Spital</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td rowSpan="5">București</td>
                                <td>Life Memorial Hospital București</td>
                            </tr>
                            <tr>
                                <td>Spitalul de Pediatrie ClinicMed</td>
                            </tr>
                            <tr>
                                {/* <td>Spitalul de Ortopedie ClinicMed</td> */}
                            </tr>
                            <tr>
                                <td>Spitalul AngioLife</td>
                            </tr>
                            <tr>
                                <td>Spitalul ClinicMed Titan</td>
                            </tr>
                            <tr>
                                <td>Arad</td>
                                <td>Spitalul ClinicMed Genesys Arad</td>
                            </tr>
                            <tr>
                                <td rowSpan="2">Brașov</td>
                                <td>Spitalul ClinicMed Brașov</td>
                            </tr>
                            <tr>
                                <td>Spitalul de Oncologie ClinicMed Brașov</td>
                            </tr>
                            <tr>
                                <td rowSpan="2">Cluj-Napoca</td>
                                <td>Spitalul ClinicMed Humanitas</td>
                            </tr>
                            <tr>
                                <td>Spitalul ClinicMed Cluj</td>
                            </tr>
                            <tr>
                                <td>Craiova</td>
                                <td>Spitalul ClinicMed Sama Craiova</td>
                            </tr>
                            <tr>
                                <td>Iași</td>
                                <td>Spitalul ClinicMed Iași</td>
                            </tr>
                            <tr>
                                {/* <td>Ploiești</td> */}
                                {/* <td>Spitalul ClinicMed Lotus Ploiești</td> */}
                            </tr>
                            <tr>
                                <td rowSpan="2">Sibiu</td>
                                <td>Spitalul ClinicMed Polisano Izvorului</td>
                            </tr>
                            <tr>
                                <td>Spitalul ClinicMed Polisano Constituției</td>
                            </tr>
                            <tr>
                                <td>Timișoara</td>
                                <td>Spitalul ClinicMed Timișoara</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div className="image-container">
                    <img src={drImage} alt="Doctor" className="dr-image" />
                </div>
            </div>
        </div>
    );
};

export default Spitale;
