import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css';
import loginlogo from '../assets/loginlogo.png'; // Imaginea pe care ai încărcat-o

const Login = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState(''); // Stare pentru mesajul de eroare
    const navigate = useNavigate();

    const handleLogin = async () => {
        console.log('Sending login request', { username, password });
        try {
            const response = await fetch('http://localhost:5000/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password }),
            });
            console.log('Response received:', response);
            const result = await response.json();
            console.log('Result:', result);
            if (response.ok) {
                localStorage.setItem('isLoggedIn', 'true');
                localStorage.setItem('userId', result.userId);
                localStorage.setItem('userType', result.userType);
                localStorage.setItem('username', username); // Stocăm numele utilizatorului
                
                // Adăugăm o condiție pentru Laborator
                if (result.userType === 'Doctori') {
                    navigate('/medic');
                } else if (result.userType === 'Administrator') {
                    navigate('/admin');
                } else if (result.userType === 'Laborator') {
                    navigate('/laborator'); // Navigăm la pagina pentru Laborator
                } else {
                    navigate('/pacient');
                }
            } else {
                setError(result.message || 'Name or password incorrect, please try again');
            }
        } catch (error) {
            console.error('Error during login request:', error);
            setError('An error occurred. Please try again.');
        }
    };

    return (
        <div className="login-container">
            <div className="login-form">
                <h2>Welcome</h2>
                <input
                    className="input"
                    placeholder="Nume"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                />
                <input
                    className="input"
                    placeholder="Parolă"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                />
                <button className="button" onClick={handleLogin}>
                    Autentificare
                </button>
                <button className="button register-button" onClick={() => navigate('/signup')}>
                    Nu ai cont? Înregistrează-te
                </button>
            </div>
            {error && (
                <div className="modal-overlay">
                    <div className="modal-content">
                        <p>{error}</p>
                        <button onClick={() => setError('')}>Close</button>
                    </div>
                </div>
            )}
            <div className="login-info">
                <img src={loginlogo} alt="Clinic Management System" className="loginlogo" />
            </div>
            <div className="footer">
                <p>
                    <button className="link-button" onClick={() => navigate('/terms')}>
                        Termeni și condiții
                    </button> | 
                    <button className="link-button" onClick={() => navigate('/privacy')}>
                        Politica de confidențialitate
                    </button>
                </p>
            </div>
        </div>
    );
};

export default Login;
