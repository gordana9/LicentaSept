//primesc mesajele
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Medic.css';
import doctorImage from '../assets/doctor.png';

const Medic = () => {
    const [doctorName, setDoctorName] = useState('');
    const [pendingAppointments, setPendingAppointments] = useState([]);
    const [futureAppointments, setFutureAppointments] = useState([]);
    const [messages, setMessages] = useState([]);
    const [showFutureAppointments, setShowFutureAppointments] = useState(false);
    const [replyMessage, setReplyMessage] = useState('');
    const [showReplyBox, setShowReplyBox] = useState({});
    const [userId, setuserId] = useState(localStorage.getItem('userId'));
    const navigate = useNavigate();

    // Safe JSON parse function to prevent errors
    const safeJSONParse = (data) => {
        try {
            return JSON.parse(data);
        } catch (e) {
            console.error('JSON parsing error:', e);
            return {};
        }
    };

    useEffect(() => {
        const doctorNameFromStorage = localStorage.getItem('username');
       // const userIdFromStorage = localStorage.getItem('userId');

        console.log('Doctor name:', doctorNameFromStorage); // Debugging log
        console.log('Doctor ID (userId):', userId); // Debugging log

        if (!doctorNameFromStorage || !userId) {
            navigate('/login');  // Redirect if no username or userId found
            return;
        }

        setDoctorName(doctorNameFromStorage);

        fetchAppointments(doctorNameFromStorage);
        fetchMessages(userId); // Fetch messages for the current doctor
    }, [navigate, userId]);

    const fetchAppointments = (doctorName) => {
        const storedAppointments = safeJSONParse(localStorage.getItem('appointments')) || [];
        const pending = storedAppointments.filter(appointment => appointment.status === 'Pending' && appointment.doctorName === doctorName);
        const future = storedAppointments.filter(appointment => appointment.status === 'Approved' && appointment.doctorName === doctorName);

        setPendingAppointments(pending);
        setFutureAppointments(future);
    };

    const fetchMessages = (userId) => {
        fetch(`http://localhost:5000/getMessages?userId=${userId}`) // Trimitem userId în cerere
            .then(response => response.json())
            .then(data => {
                console.log('Mesaje primite:', data); // Debugging log
                setMessages(data);
            })
            .catch(error => {
                console.error('Eroare la preluarea mesajelor:', error);
            });
    };

    const handleLogout = () => {
        localStorage.removeItem('username');
        localStorage.removeItem('userId');
        navigate('/login');
    };

    const sendConfirmationEmail = (appointment) => {
        // Trimite cerere HTTP către backend pentru a trimite un email real
        fetch('/approve-appointment', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                appointmentId: appointment.id,  // Presupunem că fiecare programare are un ID unic
                patientEmail: appointment.email,
                patientName: appointment.patientName,
                doctorName: appointment.doctorName,
                date: appointment.date,
                time: appointment.time
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.message) {
                console.log('Email de confirmare trimis cu succes:', data.message);
            } else {
                console.error('A apărut o eroare la trimiterea emailului de confirmare.');
            }
        })
        .catch(error => console.error('Eroare la trimiterea emailului:', error));
    };

    const handleApprove = (index) => {
        const storedAppointments = safeJSONParse(localStorage.getItem('appointments')) || [];
        const appointmentToApprove = pendingAppointments[index];
        appointmentToApprove.status = 'Approved';

        const updatedAppointments = storedAppointments.map(app =>
            app.patientName === appointmentToApprove.patientName &&
            app.doctorName === appointmentToApprove.doctorName &&
            app.date === appointmentToApprove.date &&
            app.time === appointmentToApprove.time
                ? appointmentToApprove
                : app
        );

        localStorage.setItem('appointments', JSON.stringify(updatedAppointments));
        fetchAppointments(doctorName);

        // Trimite emailul de confirmare
        sendConfirmationEmail(appointmentToApprove);
    };

    const handleReject = (index) => {
        const storedAppointments = safeJSONParse(localStorage.getItem('appointments')) || [];
        const appointmentToReject = pendingAppointments[index];
        appointmentToReject.status = 'Rejected';

        const updatedAppointments = storedAppointments.map(app =>
            app.patientName === appointmentToReject.patientName &&
            app.doctorName === appointmentToReject.doctorName &&
            app.date === appointmentToReject.date &&
            app.time === appointmentToReject.time
                ? appointmentToReject
                : app
        );

        localStorage.setItem('appointments', JSON.stringify(updatedAppointments));
        fetchAppointments(doctorName);
    };

    const toggleFutureAppointments = () => {
        setShowFutureAppointments(!showFutureAppointments);
    };

    const handleShowReplyBox = (index) => {
        setShowReplyBox(prevState => ({
            ...prevState,
            [index]: !prevState[index]
        }));
    };

    const handleSendReply = (index, patientName) => {
        const userId = localStorage.getItem('userId'); // Use userId
        const storedMessages = safeJSONParse(localStorage.getItem('messages')) || {};

        const newReply = {
            patientName: doctorName, // doctorName as the sender
            message: replyMessage,
            timestamp: new Date()
        };

        const updatedMessages = {
            ...storedMessages,
            [userId]: storedMessages[userId].map((msg, msgIndex) => {
                if (msgIndex === index) {
                    return {
                        ...msg,
                        replies: [...(msg.replies || []), newReply]
                    };
                }
                return msg;
            })
        };

        localStorage.setItem('messages', JSON.stringify(updatedMessages));
        
        // Use inline notification instead of alert
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.innerText = `Reply sent to ${patientName}: ${replyMessage}`;
        document.body.appendChild(notification);
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 3000);

        setReplyMessage('');
        setShowReplyBox({});
        setMessages(updatedMessages[userId] || []);
    };

    return (
        <div className="medic-container">
            <h1>Bun venit, {doctorName}!</h1>
            <img src={doctorImage} alt="Medic" className="image" />
            
            <div className="appointments-section">
                <h2>Programări în așteptare</h2>
                {pendingAppointments.length === 0 ? (
                    <p>Nu există programări în așteptare.</p>
                ) : (
                    <table className="appointments-table">
                        <thead>
                            <tr>
                                <th>Pacient</th>
                                <th>Data</th>
                                <th>Ora</th>
                                <th>Acțiune</th>
                            </tr>
                        </thead>
                        <tbody>
                            {pendingAppointments.map((appointment, index) => (
                                <tr key={index}>
                                    <td>{appointment.patientName}</td>
                                    <td>{appointment.date}</td>
                                    <td>{appointment.time}</td>
                                    <td>
                                        <button onClick={() => handleApprove(index)} className="approve-button">Approve</button>
                                        <button onClick={() => handleReject(index)} className="reject-button">Reject</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>

            <div className="appointments-section">
                <h2 onClick={toggleFutureAppointments} className="appointments-title">Programări viitoare</h2>
                {showFutureAppointments && (
                    <table className="appointments-table">
                        <thead>
                            <tr>
                                <th>Pacient</th>
                                <th>Specialitatea</th>
                                <th>Data</th>
                                <th>Ora</th>
                            </tr>
                        </thead>
                        <tbody>
                            {futureAppointments.map((appointment, index) => (
                                <tr key={index}>
                                    <td>{appointment.patientName}</td>
                                    <td>{appointment.specialization}</td>
                                    <td>{appointment.date}</td>
                                    <td>{appointment.time}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
            
            <div className="messages-section">
                <h2>Mesaje primite</h2>
                {messages.length === 0 ? (
                    <p>Nu există mesaje.</p>
                ) : (
                    <div className="messages-list">
                        {messages.map((msg, index) => (
                            <div key={index} className="message-card">
                                <div className="message-content">
                                    <p><strong>{msg.patientName}:</strong> {msg.message}</p>
                                    <p><small>{new Date(msg.timestamp).toLocaleString()}</small></p>
                                    {msg.replies && msg.replies.map((reply, replyIndex) => (
                                        <div key={replyIndex} className="reply-content">
                                            <p><strong>{reply.patientName}:</strong> {reply.message}</p>
                                            <p><small>{new Date(reply.timestamp).toLocaleString()}</small></p>
                                        </div>
                                    ))}
                                </div>
                                <button onClick={() => handleShowReplyBox(index)} className="reply-button">Răspunde la mesaj</button>
                                {showReplyBox[index] && (
                                    <div className="reply-box">
                                        <textarea
                                            value={replyMessage}
                                            onChange={(e) => setReplyMessage(e.target.value)}
                                            placeholder="Scrie răspunsul aici..."
                                        ></textarea>
                                        <button onClick={() => handleSendReply(index, msg.patientName)}>Trimite</button>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                )}
            </div>
            
            <button className="logout-button" onClick={handleLogout}>LOG-OUT</button>
        </div>
    );
};

export default Medic;
