import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Pacient.css';
import logo3 from '../assets/logo4.png'; // Importă imaginea logo
import phoneIcon from '../assets/phone.png'; // Importă iconița pentru telefon
import emailIcon from '../assets/email.png'; // Importă iconița pentru email

const Pacient = () => {
    const [patientName, setPatientName] = useState('');
    const [reviews, setReviews] = useState([]);
    const [showReviewForm, setShowReviewForm] = useState(false);
    const [showUserReviews, setShowUserReviews] = useState(false);
    const [rating, setRating] = useState(0);
    const [reviewText, setReviewText] = useState('');
    const [editingReviewIndex, setEditingReviewIndex] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const patientNameFromStorage = localStorage.getItem('username');
        setPatientName(patientNameFromStorage);
        fetchReviews();
    }, []);

    const fetchReviews = () => {
        const storedReviews = JSON.parse(localStorage.getItem('reviews')) || [];
        setReviews(storedReviews);
    };

    const handleLogout = () => {
        localStorage.removeItem('username'); // Elimină datele utilizatorului din localStorage
        navigate('/login'); // Redirecționează către pagina de login
    };

    const handleReviewSubmit = () => {
        const newReview = {
            patientName,
            rating,
            reviewText
        };
        let updatedReviews;
        if (editingReviewIndex !== null) {
            updatedReviews = reviews.map((review, index) =>
                index === editingReviewIndex ? newReview : review
            );
            setEditingReviewIndex(null);
        } else {
            updatedReviews = [...reviews, newReview];
        }
        setReviews(updatedReviews);
        localStorage.setItem('reviews', JSON.stringify(updatedReviews));
        setRating(0);
        setReviewText('');
        setShowReviewForm(false);
    };

    const handleDeleteReview = (index) => {
        const updatedReviews = reviews.filter((_, i) => i !== index);
        setReviews(updatedReviews);
        localStorage.setItem('reviews', JSON.stringify(updatedReviews));
    };

    const handleEditReview = (index) => {
        const review = reviews[index];
        setRating(review.rating);
        setReviewText(review.reviewText);
        setShowReviewForm(true);
        setEditingReviewIndex(index);
    };

    return (
        <div className="pacient-container">
            <div className="navbar">
                <img src={logo3} alt="Clinic Logo" className="logo3" />
                <div className="nav-links">
                    <button onClick={() => navigate('/medici')} style={{ color: 'white' }}>MEDICI</button> {/* Butonul nou adăugat */}
                    <button onClick={() => navigate('/listapreturi')} style={{ color: 'white' }}>ANALIZE ȘI PREȚURI</button>
                    <button onClick={() => navigate('/programari')}>PROGRAMĂRI</button>
                    <div className="dropdown">
                        <button className="dropbtn">LOCAȚII</button>
                        <div className="dropdown-content">
                            <button onClick={() => navigate('/spitale')}>Spitale</button>
                            <button onClick={() => navigate('/centre-recoltare')}>Centre de recoltare</button>
                        </div>
                    </div>
                    <button onClick={() => navigate('/despre-noi')}>DESPRE NOI</button>
                    <div className="dropdown">
                        <a href="#">CONTACT</a>
                        <div className="dropdown-content">
                            (021) 7302
                        </div>
                    </div>
                </div>
                <div className="right-section">
                    <button onClick={() => navigate('/programare')} className="solicita-button">+ Solicită programare</button>
                    <span className="patient-name">{patientName}</span>
                </div>
            </div>
            <div className="welcome-section">
                {/* <h1 className="clinic-name">ClinicMed Deva</h1> */}
            </div>
            <div className="content">
                <div className="contact-info" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', padding: '20px' }}>
                    <div className="map" style={{ width: '60%' }}>
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2777.54673732951!2d22.89509331171858!3d45.880377270963166!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x474ef28ea29c07d1%3A0xc6b563b6b373bb42!2sStrada%20Gheorghe%20Bari%C8%9Biu%2011%2C%20Deva%20330065!5e0!3m2!1sen!2sro!4v1718720688757!5m2!1sen!2sro"
                            width="100%"
                            height="450"
                            style={{ border: 0 }}
                            allowFullScreen=""
                            loading="lazy"
                            referrerPolicy="no-referrer-when-downgrade"
                        ></iframe>
                    </div>
                    <div className="info-panel" style={{ width: '35%', marginLeft: '5%' }}>
                        <h2 style={{ color: 'black' }}>Program Clinică</h2>
                        <div className="schedule">
                            <p><strong className="day" style={{ marginRight: '20px' }}>Luni/Miercuri</strong><span className="hours">08:00 - 14:00</span></p>
                            <p><strong className="day" style={{ marginRight: '20px' }}>Marti/Joi</strong><span className="hours">14:00 - 20:00</span></p>
                            <p><strong className="day" style={{ marginRight: '20px' }}>Vineri</strong><span className="hours">10:00 - 14:00</span></p>
                        </div>
                        <h2 style={{ color: 'black' }}>Ai nevoie de un consult?</h2>
                        <div className="contact-methods">
                            <div className="contact-item" style={{ display: 'flex', alignItems: 'center' }}>
                                <img src={phoneIcon} alt="phone icon" className="icon" style={{ marginRight: '10px' }} />
                                <p style={{ margin: 0 }}>Sună și programează<br />(021) 7302</p>
                            </div>
                            <div className="contact-item" style={{ display: 'flex', alignItems: 'center', marginTop: '10px' }}>
                                <img src={emailIcon} alt="email icon" className="icon" style={{ marginRight: '10px' }} />
                                <p style={{ margin: 0 }}>Trimite email<br />clinicmed@yahoo.com</p>
                            </div>
                        </div>
                        {/* <button className="programare-button">Programează-te!</button> */}
                    </div>
                </div>
                <div className="reviews-section">
                    <h2>Recenzii</h2>
                    {reviews.length === 0 ? (
                        <p className="no-reviews">Nu există recenzii disponibile.</p>
                    ) : (
                        reviews.map((review, index) => (
                            <div key={index} className="review">
                                <p><strong>Nume:</strong> {review.patientName}</p> {/* Afișează numele utilizatorului logat */}
                                <p><strong>Recenzie:</strong> {review.reviewText}</p>
                                <p><strong>Rating:</strong> {'★'.repeat(review.rating)}{'☆'.repeat(5 - review.rating)}</p>
                            </div>
                        ))
                    )}
                </div>
                <div style={{ display: 'flex', justifyContent: 'center', gap: '10px', marginTop: '20px' }}>
                    <button className="no-hover" onClick={() => setShowReviewForm(true)}>Lasă o recenzie</button>
                    <button className="no-hover" onClick={() => setShowUserReviews(!showUserReviews)}>Recenziile mele</button>
                </div>
                {showReviewForm && (
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: '20px' }}>
                        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '10px' }}>
                            {[...Array(5)].map((star, index) => {
                                return (
                                    <span
                                        key={index}
                                        style={{ cursor: 'pointer', color: index < rating ? 'gold' : 'grey', fontSize: '24px' }}
                                        onClick={() => setRating(index + 1)}
                                    >
                                        ★
                                    </span>
                                );
                            })}
                        </div>
                        <textarea
                            placeholder="Scrie recenzia ta..."
                            value={reviewText}
                            onChange={(e) => setReviewText(e.target.value)}
                            style={{ width: '80%', padding: '10px', marginBottom: '10px', border: '1px solid #ccc', borderRadius: '5px', height: '100px' }}
                        />
                        <button
                            onClick={handleReviewSubmit}
                            style={{ padding: '10px 20px', border: 'none', borderRadius: '5px', backgroundColor: '#0D47A1', color: 'white', cursor: 'pointer' }}
                        >
                            {editingReviewIndex !== null ? 'Salvează modificările' : 'Trimite recenzia'}
                        </button>
                    </div>
                )}
                {showUserReviews && (
                    <div className="my-reviews-section">
                        <h2>Recenziile mele</h2>
                        {reviews.filter(review => review.patientName === patientName).length === 0 ? (
                            <p className="no-reviews">Nu există recenzii personale.</p>
                        ) : (
                            reviews.filter(review => review.patientName === patientName).map((review, index) => (
                                <div key={index} className="my-review">
                                    <div className="my-review-text">
                                        <p><strong>Nume:</strong> {review.patientName}</p> {/* Afișează numele utilizatorului logat */}
                                        <p>{review.reviewText}</p>
                                        <p>{'★'.repeat(review.rating)}{'☆'.repeat(5 - review.rating)}</p>
                                    </div>
                                    <div className="my-review-buttons">
                                        <button
                                            onClick={() => handleEditReview(index)}
                                            className="edit-button"
                                        >
                                            Editează
                                        </button>
                                        <button
                                            onClick={() => handleDeleteReview(index)}
                                            className="delete-button"
                                        >
                                            Șterge
                                        </button>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                )}
            </div>
            <button className="logout-button" onClick={handleLogout}>Logout</button>
        </div>
    );
};

export default Pacient;
