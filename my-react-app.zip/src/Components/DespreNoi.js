import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './DespreNoi.css';
import logo3 from '../assets/logo4.png'; // Importă imaginea logo
import desprenoiImg from '../assets/clinicmed.png'; // Importă imaginea "clinicmed.png"
import aImage from '../assets/a.png'; // Importă imaginea "a.png"
import bImage from '../assets/b.png'; // Importă imaginea "b.png"

const DespreNoi = () => {
    const [patientName, setPatientName] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const patientNameFromStorage = localStorage.getItem('username');
        setPatientName(patientNameFromStorage);
    }, []);

    const handleLogout = () => {
        localStorage.removeItem('username');
        localStorage.removeItem('userId');
        navigate('/login');
    };

    return (
        <div className="despre-noi-container">
            <div className="navbar">
                <img src={logo3} alt="Clinic Logo" className="logo3" />
                <div className="nav-links">
                <a href="#" onClick={() => navigate('/pacient', { replace: true })}>HOME</a>
                    <a href="#" onClick={() => navigate('/listapreturi')} style={{ color: 'white' }}>ANALIZE ȘI PREȚURI</a>
                    <a href="#" onClick={() => navigate('/programari')}>PROGRAMĂRI</a>
                    <div className="dropdown">
                        <button className="dropbtn">LOCAȚII</button>
                        <div className="dropdown-content">
                            <button onClick={() => navigate('/spitale', { replace: true })}>Spitale</button>
                            {/* <button onClick={() => navigate('/centre-cas', { replace: true })}>Centre CAS</button> */}
                            <button onClick={() => navigate('/centre-recoltare', { replace: true })}>Centre de recoltare</button>
                        </div>
                    </div>
                    <a href="#" onClick={() => navigate('/despre-noi')}>DESPRE NOI</a>
                    <div className="dropdown">
                        <a href="#">CONTACT</a>
                        <div className="dropdown-content">
                            (021) 7302
                        </div>
                    </div>
                </div>
                <div className="right-section">
                    <button onClick={() => navigate('/programare')} className="solicita-button">+ Solicita programare</button>
                    <div className="user-info">
                        <span className="patient-name">{patientName}</span>
                        {/* <button className="logout-button" onClick={handleLogout}>LOG-OUT</button> */}
                    </div>
                </div>
            </div>
            <div className="despre-noi-content">
                <div className="text-content">
                    <h1>Despre ClinicMed</h1>
                    <p>
                        Sistemul Medical ClinicMed a pornit acum aproape trei decenii, s-a dezvoltat sănătos și a devenit cel mai mare furnizor de servicii medicale private din România. Antreprenorii români care au pus bazele acestei companii au investit și s-au implicat pentru a aduce schimbare în sistemul de sănătate românesc, au crezut în inovație și au îndrăznit să țintească cât mai sus, pentru a oferi pacienților români cea mai bună îngrijire, chiar la ei acasă.
                    </p>
                </div>
                <img src={desprenoiImg} alt="Despre noi" className="desprenoi-img" />
            </div>
            <div className="additional-section">
                <img src={aImage} alt="Medical team" className="a-image" />
                <div className="additional-text">
                    <p>
                        ClinicMed este compania care își dedică toate resursele pentru a asigura fiecărui pacient servicii medicale profesioniste, la cele mai înalte standarde, asigurate de medici și specialiști români, alături de echipamente și tehnologii de ultimă generație, în condiții impecabile de siguranță și confort.
                    </p>
                    <p>
                        Sănătatea este profesia și pasiunea noastră, iar obiectivul nostru este să îmbunătățim calitatea vieții fiecărui pacient care ne trece pragul. Accesul la serviciile noastre este facilitat de sistemul integrat pe care îl aplicăm: ambulatoriu, spital, laborator de analize, farmacie, imagistică, abonamente corporate și servicii de wellness.
                    </p>
                </div>
            </div>
            <div className="additional-section">
                <div className="additional-text">
                    <p>
                        În perioada pandemiei de COVID-19, ClinicMed a reușit să joace un rol esențial în societate și a obținut statutul de lider detașat în monitorizarea pandemiei, prin implicarea activă în zona de cercetare.
                    </p>
                    <p>
                        Ne bucurăm de recunoașterea internațională a calității serviciilor noastre, prin susținerea pe care o avem din partea International Finance Corporation - divizia de consultanță financiară a Grupului Băncii Mondiale, precum și a Societe Generale, care au ales să ne sprijine, devenind acționari ClinicMed.
                    </p>
                </div>
                <img src={bImage} alt="Research" className="b-image" />
            </div>
        </div>
    );
};

export default DespreNoi;
