//pagina unde pacientului isi vizualizeaza toate programarile
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './ProgramariPacient.css';
import logo3 from '../assets/logo4.png';

const ProgramariPacient = () => {
    const [patientName, setPatientName] = useState('');
    const [pendingAppointments, setPendingAppointments] = useState([]);
    const [futureAppointments, setFutureAppointments] = useState([]);
    const [rejectedAppointments, setRejectedAppointments] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        const patientNameFromStorage = localStorage.getItem('username');
        setPatientName(patientNameFromStorage);
        fetchAppointments(patientNameFromStorage);
    }, []);

    const fetchAppointments = (patientName) => {
        const storedAppointments = JSON.parse(localStorage.getItem('appointments')) || [];
        const pending = storedAppointments.filter(app => app.status === 'Pending' && app.patientName === patientName);
        const future = storedAppointments.filter(app => app.status === 'Approved' && app.patientName === patientName);
        const rejected = storedAppointments.filter(app => app.status === 'Rejected' && app.patientName === patientName);
        setPendingAppointments(pending);
        setFutureAppointments(future);
        setRejectedAppointments(rejected);
    };

    const handleLogout = () => {
        localStorage.removeItem('username');
        localStorage.removeItem('userId');
        navigate('/login');
    };

    return (
        <div className="programari-pacient-container">
            <div className="navbar">
                <img src={logo3} alt="Clinic Logo" className="logo3" />
                <div className="nav-links">
                    <a href="#" onClick={() => navigate('/pacient', { replace: true })}>HOME</a>
                    <a href="#" onClick={() => navigate('/listapreturi')} style={{ color: 'white' }}>ANALIZE ȘI PREȚURI</a>
                    <a href="#" onClick={() => navigate('/programari')}>PROGRAMĂRI</a>
                    <div className="dropdown">
                        <button className="dropbtn">LOCAȚII</button>
                        <div className="dropdown-content">
                            <button onClick={() => navigate('/spitale', { replace: true })}>Spitale</button>
                            <button onClick={() => navigate('/centre-recoltare', { replace: true })}>Centre de recoltare</button>
                        </div>
                    </div>
                    <a href="#" onClick={() => navigate('/despre-noi')}>DESPRE NOI</a>
                    <div className="dropdown">
                        <a href="#">CONTACT</a>
                        <div className="dropdown-content">
                            (021) 7302
                        </div>
                    </div>
                </div>
                <div className="right-section">
                    <button onClick={() => navigate('/programare')} className="solicita-button">+ Solicita programare</button>
                    <div className="user-info">
                        <span className="patient-name">{patientName}</span>
                    </div>
                </div>
            </div>
            <div className="programari-content">
                <h1>Programările Mele</h1>
                <div className="programari-section">
                    <h2>Programări în așteptare</h2>
                    {pendingAppointments.length === 0 ? (
                        <p>Nu există programări în așteptare.</p>
                    ) : (
                        pendingAppointments.map((appointment, index) => (
                            <div key={index} className="programare-detalii">
                                <p><strong>Specializarea:</strong> {appointment.specialization}</p>
                                <p><strong>Nume doctor:</strong> {appointment.doctorName}</p>
                                <p><strong>Data:</strong> {appointment.date}</p>
                                <p><strong>Ora:</strong> {appointment.time}</p>
                            </div>
                        ))
                    )}
                </div>
                <div className="programari-section">
                    <h2>Programări viitoare</h2>
                    {futureAppointments.length === 0 ? (
                        <p>Nu există programări viitoare.</p>
                    ) : (
                        futureAppointments.map((appointment, index) => (
                            <div key={index} className="programare-detalii">
                                <p><strong>Specializarea:</strong> {appointment.specialization}</p>
                                <p><strong>Nume doctor:</strong> {appointment.doctorName}</p>
                                <p><strong>Data:</strong> {appointment.date}</p>
                                <p><strong>Ora:</strong> {appointment.time}</p>
                            </div>
                        ))
                    )}
                </div>
                <div className="programari-section">
                    <h2>Programări respinse</h2>
                    {rejectedAppointments.length === 0 ? (
                        <p>Nu există programări respinse.</p>
                    ) : (
                        rejectedAppointments.map((appointment, index) => (
                            <div key={index} className="programare-detalii">
                                <p><strong>Specializarea:</strong> {appointment.specialization}</p>
                                <p><strong>Nume doctor:</strong> {appointment.doctorName}</p>
                                <p><strong>Data:</strong> {appointment.date}</p>
                                <p><strong>Ora:</strong> {appointment.time}</p>
                            </div>
                        ))
                    )}
                </div>
            </div>
        </div>
    );
};

export default ProgramariPacient;
