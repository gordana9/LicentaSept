import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import logo3 from '../assets/logo4.png'; // Actualizează calea către logo-ul tău
import tube from '../assets/tube.png'; // Actualizează calea către imaginea tube
import research from '../assets/cercetare.png'; // Actualizează calea către imaginea de cercetare
import './CentreRecoltare.css';

const CentreRecoltare = () => {
    const [patientName, setPatientName] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const patientNameFromStorage = localStorage.getItem('username');
        if (patientNameFromStorage) {
            setPatientName(patientNameFromStorage);
        }
    }, []);

    const handleLogout = () => {
        localStorage.removeItem('username');
        localStorage.removeItem('userId');
        navigate('/login');
    };

    return (
        <div className="centre-recoltare-container">
            <div className="navbar">
                <img src={logo3} alt="Clinic Logo" className="logo3" />
                <div className="nav-links">
                <a href="#" onClick={() => navigate('/pacient', { replace: true })}>HOME</a>
                    <button onClick={() => navigate('/listapreturi')} style={{ color: 'white' }}>ANALIZE ȘI PREȚURI</button>
                    <button onClick={() => navigate('/programari')}>PROGRAMĂRI</button>
                    <div className="dropdown">
                        <button className="dropbtn">LOCAȚII</button>
                        <div className="dropdown-content">
                            <button onClick={() => navigate('/spitale')}>Spitale</button>
                            {/* <button onClick={() => navigate('/centre-cas')}>Centre CAS</button> */}
                            <button onClick={() => navigate('/centre-recoltare')}>Centre de recoltare</button>
                        </div>
                    </div>
                    <button onClick={() => navigate('/despre-noi')}>DESPRE NOI</button>
                    <div className="dropdown">
                        <a href="#">CONTACT</a>
                        <div className="dropdown-content">
                            (021) 7302
                        </div>
                    </div>
                </div>
                <div className="right-section">
                    <button onClick={() => navigate('/programare')} className="solicita-button">+ Solicita programare</button>
                    <div className="user-info">
                        <span className="patient-name">{patientName}</span>
                        {/* <button className="logout-button" onClick={handleLogout}>LOG-OUT</button> */}
                    </div>
                </div>
            </div>

            <div className="content-container">
                <div className="centre-recoltare-content">
                    <div className="clinici-recoltare">
                        <div className="clinici-row">
                            <div className="clinica-card">
                                <h3>ClinicMed Făget</h3>
                                <p>Calea Lugojului nr. 42</p>
                                <p>(021) 5602</p>
                                <p><strong>Făget</strong></p>
                                <p>Centru de recoltare</p>
                                <img src={tube} alt="Tube" className="tube-image" />
                            </div>
                            <div className="clinica-card">
                                <h3>ClinicMed Timișoara (Martirilor)</h3>
                                <p>Calea Martirilor 1989, nr. 21, scara C</p>
                                <p>(031) 6081)</p>
                                <p><strong>Timișoara</strong></p>
                                <p>Centru de recoltare</p>
                                <img src={tube} alt="Tube" className="tube-image" />
                            </div>
                        </div>
                        <div className="clinici-row">
                            <div className="clinica-card">
                                <h3>ClinicMed Jimbolia</h3>
                                <p>Str. Republicii, nr. 53, ap. 1A</p>
                                <p>(031) 5092</p>
                                <p><strong>Jimbolia</strong></p>
                                <p>Centru de recoltare</p>
                                <img src={tube} alt="Tube" className="tube-image" />
                            </div>
                            <div className="clinica-card">
                                <h3>ClinicMed Deta</h3>
                                <p>Str. Victoriei, nr. 24</p>
                                <p>(021) 4107</p>
                                <p><strong>Deta</strong></p>
                                <p>Centru de recoltare</p>
                                <img src={tube} alt="Tube" className="tube-image" />
                            </div>
                        </div>
                        <div className="clinici-row">
                            <div className="clinica-card">
                                <h3>ClinicMed Lugoj</h3>
                                <p>Str. Cuza Vodă, nr. 2A</p>
                                <p>(031) 6204</p>
                                <p><strong>Lugoj</strong></p>
                                <p>Centru de recoltare</p>
                                <img src={tube} alt="Tube" className="tube-image" />
                            </div>
                            <div className="clinica-card">
                                <h3>ClinicMed Timișoara (Calea Bogdăneștilor)</h3>
                                <p>Calea Bogdăneștilor, nr. 6</p>
                                <p>(021) 7302</p>
                                <p><strong>Timișoara</strong></p>
                                <p>Laborator, Centru de recoltare</p>
                                <img src={tube} alt="Tube" className="tube-image" />
                            </div>
                        </div>
                    </div>
                    <div className="research-image-container">
                        <img src={research} alt="Research" className="research-image" />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CentreRecoltare;
