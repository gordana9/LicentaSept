import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Laborator.css';

const Laborator = () => {
    const [userName, setUserName] = useState('');
    const [userID, setUserID] = useState(null);
    const [pendingAnalize, setPendingAnalize] = useState([]);
    const [acceptedAnalize, setAcceptedAnalize] = useState([]);
    const [finalizedAnalize, setFinalizedAnalize] = useState([]);
    const [uploadingIndex, setUploadingIndex] = useState(null);
    const [uploadedFile, setUploadedFile] = useState(null);
    const [uploadedFiles, setUploadedFiles] = useState([]);
    const [activeSection, setActiveSection] = useState(''); // Stare pentru secțiunea activă

    const navigate = useNavigate();

    useEffect(() => {
        const storedUserName = localStorage.getItem('username');
        const storedUserID = localStorage.getItem('userID');
        if (storedUserName) {
            setUserName(storedUserName);
        }
        if (storedUserID) {
            setUserID(storedUserID);
        }

        const storedPendingAnalize = JSON.parse(localStorage.getItem('adminData')) || [];
        setPendingAnalize(storedPendingAnalize);

        const storedAcceptedAnalize = JSON.parse(localStorage.getItem('acceptedData')) || [];
        setAcceptedAnalize(storedAcceptedAnalize);

        const storedFinalizedAnalize = JSON.parse(localStorage.getItem('finalizedData')) || [];
        setFinalizedAnalize(storedFinalizedAnalize);

        const storedUploadedFiles = JSON.parse(localStorage.getItem('uploadedFiles')) || [];
        setUploadedFiles(storedUploadedFiles);
    }, []);

    const handleAccept = (index) => {
        const acceptedEntry = pendingAnalize[index];
        const updatedPendingAnalize = pendingAnalize.filter((_, i) => i !== index);
        const updatedAcceptedAnalize = [...acceptedAnalize, acceptedEntry];

        setPendingAnalize(updatedPendingAnalize);
        setAcceptedAnalize(updatedAcceptedAnalize);

        localStorage.setItem('adminData', JSON.stringify(updatedPendingAnalize));
        localStorage.setItem('acceptedData', JSON.stringify(updatedAcceptedAnalize));
    };

    const handleUploadClick = (index) => {
        setUploadingIndex(index);
        setUploadedFile(null);
    };

    const handleFileChange = (e) => {
        const file = e.target.files[0];
        if (file && file.type === 'application/pdf') {
            setUploadedFile(file);
        } else {
            alert('Te rog să încarci un fișier de tip PDF.');
            setUploadedFile(null);
        }
    };

    const handleSubmitUpload = () => {
        if (uploadedFile) {
            const reader = new FileReader();
            reader.onloadend = () => {
                const fileData = {
                    userID,
                    name: uploadedFile.name,
                    url: reader.result
                };

                let existingFiles = JSON.parse(localStorage.getItem('uploadedFiles')) || [];
                existingFiles.push(fileData);
                localStorage.setItem('uploadedFiles', JSON.stringify(existingFiles));

                setUploadedFiles(existingFiles);

                const finalizedEntry = acceptedAnalize[uploadingIndex];
                const updatedAcceptedAnalize = acceptedAnalize.filter((_, i) => i !== uploadingIndex);
                const updatedFinalizedAnalize = [...finalizedAnalize, finalizedEntry];

                setAcceptedAnalize(updatedAcceptedAnalize);
                setFinalizedAnalize(updatedFinalizedAnalize);

                localStorage.setItem('acceptedData', JSON.stringify(updatedAcceptedAnalize));
                localStorage.setItem('finalizedData', JSON.stringify(updatedFinalizedAnalize));

                alert('Fișierul a fost trimis cu succes!');
                setUploadingIndex(null);
            };
            reader.readAsDataURL(uploadedFile);
        } else {
            alert('Te rog să încarci un fișier înainte de a trimite.');
        }
    };

    const handleLogout = () => {
        localStorage.removeItem('username');
        localStorage.removeItem('userID');
        navigate('/login');
    };

    const toggleSection = (section) => {
        setActiveSection(activeSection === section ? '' : section);
    };

    const renderContent = () => {
        return (
            <div>
                {/* Analize în așteptare */}
                <div className={`analysis-category ${activeSection === 'pending' ? 'active' : ''}`}>
                    <h2 onClick={() => toggleSection('pending')}>Analize în așteptare</h2>
                    {activeSection === 'pending' && (
                        <div className="analysis-content">
                            {pendingAnalize.length === 0 ? (
                                <p>Nu există analize în așteptare.</p>
                            ) : (
                                pendingAnalize.map((entry, index) => (
                                    <div key={index} className="patient-entry">
                                        <h3>{entry.patientName}</h3>
                                        <ul>
                                            {entry.selectedAnalize.map((analiza, i) => (
                                                <li key={i}>{analiza.nume} - {analiza.pret} Lei</li>
                                            ))}
                                        </ul>
                                        <button onClick={() => handleAccept(index)} className="accept-button">Acceptă</button>
                                    </div>
                                ))
                            )}
                        </div>
                    )}
                </div>

                {/* Analize acceptate */}
                <div className={`analysis-category ${activeSection === 'accepted' ? 'active' : ''}`}>
                    <h2 onClick={() => toggleSection('accepted')}>Analize acceptate</h2>
                    {activeSection === 'accepted' && (
                        <div className="analysis-content">
                            {acceptedAnalize.length === 0 ? (
                                <p>Nu există analize acceptate.</p>
                            ) : (
                                acceptedAnalize.map((entry, index) => (
                                    <div key={index} className="patient-entry">
                                        <h3>{entry.patientName}</h3>
                                        <ul>
                                            {entry.selectedAnalize.map((analiza, i) => (
                                                <li key={i}>{analiza.nume}</li>
                                            ))}
                                        </ul>
                                        <button onClick={() => handleUploadClick(index)} className="upload-button">Încarcă analize</button>
                                        {uploadingIndex === index && (
                                            <div className="upload-section">
                                                <input type="file" accept=".pdf" onChange={handleFileChange} />
                                                <button onClick={handleSubmitUpload} className="submit-button">Trimite</button>
                                            </div>
                                        )}
                                    </div>
                                ))
                            )}
                        </div>
                    )}
                </div>

                {/* Analize finalizate */}
                <div className={`analysis-category ${activeSection === 'finalized' ? 'active' : ''}`}>
                    <h2 onClick={() => toggleSection('finalized')}>Analize finalizate</h2>
                    {activeSection === 'finalized' && (
                        <div className="analysis-content">
                            {finalizedAnalize.length === 0 ? (
                                <p>Nu există analize finalizate.</p>
                            ) : (
                                finalizedAnalize.map((entry, index) => (
                                    <div key={index} className="patient-entry">
                                        <h3>{entry.patientName}</h3>
                                        <ul>
                                            {entry.selectedAnalize.map((analiza, i) => (
                                                <li key={i}>{analiza.nume}</li>
                                            ))}
                                        </ul>
                                        {uploadedFiles
                                            .filter(file => file.userID === userID)
                                            .map((file, fileIndex) => (
                                                <p key={fileIndex}>{file.name}</p>
                                            ))
                                        }
                                    </div>
                                ))
                            )}
                        </div>
                    )}
                </div>
            </div>
        );
    };

    return (
        <div className="laborator-container">
            <div className="header">
                <h1>Bine ai venit, {userName}!</h1>
                <button className="logout-button" onClick={handleLogout}>Log Out</button>
            </div>
            <div className="content">
                {renderContent()}
            </div>
        </div>
    );
};

export default Laborator;
