import React, { useEffect, useState } from 'react';
import { Bar } from 'react-chartjs-2';
import { Chart, registerables } from 'chart.js';
import './Statistics.css';

Chart.register(...registerables);

const Statistics = () => {
    const [stats, setStats] = useState({
        patients: 0,
        doctors: 0,
        appointments: 0,
    });

    useEffect(() => {
        const fetchStats = async () => {
            try {
                const patientsResponse = await fetch('http://localhost:5000/api/stats/patients');
                const patientsData = await patientsResponse.json();

                const doctorsResponse = await fetch('http://localhost:5000/api/stats/doctors');
                const doctorsData = await doctorsResponse.json();

                const appointmentsResponse = await fetch('http://localhost:5000/api/stats/appointments');
                const appointmentsData = await appointmentsResponse.json();

                setStats({
                    patients: patientsData.count,
                    doctors: doctorsData.count,
                    appointments: appointmentsData.count,
                });
            } catch (error) {
                console.error('Error fetching stats:', error);
            }
        };

        fetchStats();
    }, []);

    const data = {
        labels: ['Pacienți', 'Medici', 'Programări'],
        datasets: [
            {
                label: 'Statistici',
                data: [stats.patients, stats.doctors, stats.appointments],
                backgroundColor: ['#0D47A1', '#1976D2', '#42A5F5'],
            },
        ],
    };

    const options = {
        responsive: true,
        plugins: {
            legend: {
                display: false,
            },
            title: {
                display: true,
                text: 'Statistici Clinica Medicală',
            },
        },
    };

    return (
        <div className="statistics-container">
            <h2>Privire de ansamblu asupra activității</h2>
            <div className="chart-container">
                <Bar data={data} options={options} />
            </div>
        </div>
    );
};

export default Statistics;
