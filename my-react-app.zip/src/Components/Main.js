import React from 'react';

const Main = () => {
    return <div>Main Page</div>;
};

export default Main;
