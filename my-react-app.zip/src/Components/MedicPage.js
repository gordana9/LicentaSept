import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './MedicPage.css';
import logo3 from '../assets/logo4.png'; // Importă imaginea logo

const MedicPage = () => {
    const [patientName, setPatientName] = useState('');
    const [specializari, setSpecializari] = useState([]);
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const [selectedSpecializare, setSelectedSpecializare] = useState('');
    const [doctors, setDoctors] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [showMessageBox, setShowMessageBox] = useState({});
    const [messages, setMessages] = useState({});
    const [doctorMessages, setDoctorMessages] = useState([]);
    const [replyMessage, setReplyMessage] = useState('');
    const [showReplyBox, setShowReplyBox] = useState({});
    const navigate = useNavigate();

    useEffect(() => {
        const patientNameFromStorage = localStorage.getItem('username');
        const userIdFromStorage = localStorage.getItem('userId'); // Obține userId din localStorage

        console.log('Patient name:', patientNameFromStorage); // Debugging log
        console.log('User ID (userId):', userIdFromStorage); // Debugging log

        setPatientName(patientNameFromStorage || '');
        fetchSpecializari();
        fetchDoctorMessages();
    }, []);

    const fetchSpecializari = async () => {
        try {
            const response = await fetch('http://localhost:5000/specializations');
            const data = await response.json();
            console.log('Specializari fetched:', data);
            setSpecializari(data);
        } catch (error) {
            console.error('Eroare la preluarea specializărilor:', error);
        }
    };

    const fetchDoctorsBySpecializare = async (specializare) => {
        try {
            const response = await fetch(`http://localhost:5000/doctors?specialization=${specializare}`);
            const data = await response.json();
            console.log('Doctors fetched:', data);
            setDoctors(data);
        } catch (error) {
            console.error('Eroare la preluarea doctorilor:', error);
        }
    };

    const fetchDoctorMessages = () => {
        try {
            const userId = localStorage.getItem('userId');
            fetch(`http://localhost:5000/getMessages?userId=${userId}`)
                .then(response => response.json())
                .then(data => {
                    setDoctorMessages(data);
                })
                .catch(error => {
                    console.error('Eroare la preluarea mesajelor:', error);
                    setDoctorMessages([]);
                });
        } catch (error) {
            console.error('Eroare la preluarea mesajelor:', error);
            setDoctorMessages([]);
        }
    };

    const handleSpecializareClick = (specializare) => {
        setSelectedSpecializare(specializare);
        setIsDropdownOpen(false);
        fetchDoctorsBySpecializare(specializare);
    };

    const handleSearch = (event) => {
        setSearchTerm(event.target.value);
    };

    const filteredDoctors = doctors.filter(doctor =>
        doctor.Nume.toLowerCase().includes(searchTerm.toLowerCase()) ||
        doctor.Prenume.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const handleShowMessageBox = (doctorId) => {
        setShowMessageBox(prevState => ({
            ...prevState,
            [doctorId]: !prevState[doctorId]
        }));
    };

    const handleMessageChange = (doctorId, value) => {
        setMessages(prevMessages => ({
            ...prevMessages,
            [doctorId]: value
        }));
    };

    const handleSendMessage = (userId) => {
        try {
            const messagesFromStorage = JSON.parse(localStorage.getItem('messages')) || {};
            const patientName = localStorage.getItem('username'); // Numele pacientului care trimite mesajul
    
            if (!messagesFromStorage[userId]) {
                messagesFromStorage[userId] = [];
            }
    
            messagesFromStorage[userId].push({
                patientName,
                message: messages[userId],
                timestamp: new Date()
            });
    
            localStorage.setItem('messages', JSON.stringify(messagesFromStorage));
    
            // Trimitere mesaj către server
            fetch('http://localhost:5000/sendMessage', { // Asigură-te că folosești URL-ul complet
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    userId, // Folosim userId pentru identificare
                    patientName,
                    message: messages[userId]
                }),
            })
            .then(response => response.json())
            .then(data => {
                console.log('Mesaj trimis:', data.message);
            })
            .catch(error => {
                console.error('Eroare la trimiterea mesajului către server:', error);
            });
    
            alert('Mesaj trimis cu succes!');
            setMessages(prevMessages => ({
                ...prevMessages,
                [userId]: ''
            }));
            setShowMessageBox({});
        } catch (error) {
            console.error('Eroare la trimiterea mesajului:', error);
        }
    };
    
    const handleReplyMessageChange = (index, value) => {
        setReplyMessage(value);
    };

    const handleSendReply = (index, userId, patientName) => {
        try {
            const userIdFromStorage = JSON.parse(localStorage.getItem('userId'));
            const messagesFromStorage = JSON.parse(localStorage.getItem('messages')) || {};
            if (!messagesFromStorage[userIdFromStorage]) {
                messagesFromStorage[userIdFromStorage] = [];
            }

            if (!messagesFromStorage[userIdFromStorage][index].replies) {
                messagesFromStorage[userIdFromStorage][index].replies = [];
            }

            messagesFromStorage[userIdFromStorage][index].replies.push({
                patientName: userId,
                message: replyMessage,
                timestamp: new Date()
            });

            localStorage.setItem('messages', JSON.stringify(messagesFromStorage));
            alert(`Reply sent to ${patientName}: ${replyMessage}`);
            setReplyMessage('');
            setShowReplyBox({});
            setDoctorMessages(messagesFromStorage[userIdFromStorage]);
        } catch (error) {
            console.error('Eroare la trimiterea răspunsului:', error);
        }
    };

    const handleShowReplyBox = (index) => {
        setShowReplyBox(prevState => ({
            ...prevState,
            [index]: !prevState[index]
        }));
    };

    const handleLogout = () => {
        localStorage.removeItem('username');
        localStorage.removeItem('userId');
        navigate('/login');
    };

    return (
        <div className="medic-container">
            <div className="navbar">
                <img src={logo3} alt="Clinic Logo" className="logo3" />
                <div className="nav-links">
                    <a href="#" onClick={() => navigate('/pacient', { replace: true })}>HOME</a>
                    <a href="#" onClick={() => navigate('/listapreturi')} style={{ color: 'white' }}>ANALIZE ȘI PREȚURI</a>
                    <a href="#" onClick={() => navigate('/programari')}>PROGRAMĂRI</a>
                    <div className="dropdown">
                        <button className="dropbtn">LOCAȚII</button>
                         <div className="dropdown-content">
                            <button onClick={() => navigate('/spitale', { replace: true })}>Spitale</button>
                            <button onClick={() => navigate('/centre-recoltare', { replace: true })}>Centre de recoltare</button>
                        </div>
                    </div>
                    <a href="#" onClick={() => navigate('/despre-noi')}>DESPRE NOI</a>
                    <div className="dropdown">
                        <a href="#">CONTACT</a>
                        <div className="dropdown-content">
                            (021) 7302
                        </div>
                    </div>
                </div>
                <div className="right-section">
                    <button onClick={() => navigate('/programare')} className="solicita-button">+ Solicita programare</button>
                    <div className="user-info">
                        <span className="patient-name">{patientName}</span>
                    </div>
                </div>
            </div>
            <div className="medic-content">
                <div className="vertical-bar"></div>
                <h1 className="medic-title">Medicii ClinicMed</h1>
                <div className="search-and-specialitati">
                    <div className="specialitati-section">
                        <h2 onClick={() => setIsDropdownOpen(!isDropdownOpen)} className="specialitati-title">
                            Specialități <span className="arrow">{isDropdownOpen ? '▲' : '▼'}</span>
                        </h2>
                        {isDropdownOpen && (
                            <ul className="specialitati-list">
                                {specializari.map((specializare, index) => (
                                    <li key={index} onClick={() => handleSpecializareClick(specializare)}>
                                        {specializare}
                                    </li>
                                ))}
                            </ul>
                        )}
                    </div>
                    <input
                        type="text"
                        placeholder="Caută numele medicului"
                        value={searchTerm}
                        onChange={handleSearch}
                        className="search-bar"
                    />
                </div>
                <div className="doctor-list">
                    {filteredDoctors.map((doctor, index) => (
                        <div key={index} className="doctor-card">
                            <div className="doctor-info">
                                <h3>{doctor.Nume} {doctor.Prenume}</h3>
                                <p>Medic Specialist</p>
                                <p>{selectedSpecializare}</p>
                            </div>
                            <div className="contact-info">
                                <p>Telefon: {doctor.NumarTelefon}</p>
                                <p>Email: {doctor.Email}</p>
                                <button onClick={() => handleShowMessageBox(doctor.UserID)}>Trimite mesaj</button>
                                {showMessageBox[doctor.UserID] && (
                                    <div className="message-box">
                                        <textarea
                                            value={messages[doctor.UserID] || ''}
                                            onChange={(e) => handleMessageChange(doctor.UserID, e.target.value)}
                                            placeholder="Scrie mesajul aici..."
                                        ></textarea>
                                        <button onClick={() => handleSendMessage(doctor.UserID)}>Trimite</button>
                                    </div>
                                )}
                            </div>
                        </div>
                    ))}
                </div>

                <div className="messages-section">
                    <h2>Mesaje primite</h2>
                    {doctorMessages.length === 0 ? (
                        <p>Nu există mesaje.</p>
                    ) : (
                        <div className="messages-list">
                            {doctorMessages.map((msg, index) => (
                                <div key={index} className="message-card">
                                    <div className="message-content">
                                        <p><strong>{msg.patientName}:</strong> {msg.message}</p>
                                        <p><small>{new Date(msg.timestamp).toLocaleString()}</small></p>
                                        {msg.replies && msg.replies.map((reply, replyIndex) => (
                                            <div key={replyIndex} className="reply-content">
                                                <p><strong>{reply.patientName}:</strong> {reply.message}</p>
                                                <p><small>{new Date(reply.timestamp).toLocaleString()}</small></p>
                                            </div>
                                        ))}
                                    </div>
                                    <button onClick={() => handleShowReplyBox(index)}>Raspunde la mesaj</button>
                                    {showReplyBox[index] && (
                                        <div className="reply-box">
                                            <textarea
                                                value={replyMessage}
                                                onChange={(e) => handleReplyMessageChange(index, e.target.value)}
                                                placeholder="Scrie răspunsul aici..."
                                            ></textarea>
                                            <button onClick={() => handleSendReply(index, msg.patientName)}>Trimite</button>
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default MedicPage;
