import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const AddPatient = () => {
    const [formData, setFormData] = useState({
        Nume: '',
        Prenume: '',
        Varsta: '',
        CNP: '',
        Adresa: '',
        NumarTelefon: '',
        Email: '',
        Profesie: '',
        LocMunca: '',
        IstoricMedical: '',
        Alergii: '',
        ConsultatiiCardiologice: ''
    });

    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:5000/api/addPatient', formData);
            navigate('/medici'); // Redirecționează la pagina principală a medicului
        } catch (error) {
            console.error('Error adding patient:', error);
        }
    };

    return (
        <div className="add-patient">
            <h2>Adaugă Pacient</h2>
            <form onSubmit={handleSubmit}>
                {Object.keys(formData).map((key) => (
                    <div key={key} className="form-group">
                        <input
                            type="text"
                            name={key}
                            value={formData[key]}
                            onChange={handleChange}
                            placeholder={key}
                            required
                        />
                    </div>
                ))}
                <button type="submit">Adaugă Pacient</button>
            </form>
        </div>
    );
};

export default AddPatient;
