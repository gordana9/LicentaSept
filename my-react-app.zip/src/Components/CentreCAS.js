import React from 'react';
import './CentreCAS.css';
import logo3 from '../assets/logo4.png'; // Importă imaginea logo
import { useNavigate } from 'react-router-dom'; // Importă hook-ul de navigare

const CentreCAS = () => {
    const navigate = useNavigate(); // Hook pentru navigare
    const patientName = localStorage.getItem('username'); // Obține numele utilizatorului din localStorage

    const handleLogout = () => {
        localStorage.removeItem('username');
        localStorage.removeItem('userId');
        navigate('/login');
    };

    return (
        <div className="centre-cas-container">
            <div className="navbar">
                <img src={logo3} alt="Clinic Logo" className="logo3" />
                <div className="nav-links">
                    <button onClick={() => navigate('/pacient', { replace: true })} className="nav-button">HOME</button>
                    <button onClick={() => navigate('/listapreturi')} className="nav-button">ANALIZE ȘI PREȚURI</button>
                    <button onClick={() => navigate('/programari')} className="nav-button">PROGRAMĂRI</button>
                    <div className="dropdown">
                        <button className="dropbtn">LOCAȚII</button>
                        <div className="dropdown-content">
                            <button onClick={() => navigate('/spitale')}>Spitale</button>
                            <button onClick={() => navigate('/centre-cas')}>Centre CAS</button>
                            <button onClick={() => navigate('/centre-recoltare')}>Centre de recoltare</button>
                        </div>
                    </div>
                    <button onClick={() => navigate('/despre-noi')} className="nav-button">DESPRE NOI</button>
                    <div className="dropdown">
                        <button className="dropbtn">CONTACT</button>
                        <div className="dropdown-content">
                            (021) 7302
                        </div>
                    </div>
                </div>
                <div className="right-section">
                    <button onClick={() => navigate('/programare')} className="solicita-button">+ Solicita programare</button>
                    <div className="user-info">
                        <span className="patient-name">{patientName}</span>
                        <button onClick={handleLogout} className="logout-button">Logout</button>
                    </div>
                </div>
            </div>
            <div className="content">
                <h1 className="title">Listă centre CAS</h1>
                <p>Lista centrelor ClinicMed România care sunt în contract de colaborare cu Casa de Asigurări de Sănătate.</p>
                <p className="bold-text">Vă informăm că, pentru efectuarea analizelor în baza biletului de trimitere CAS, este necesară programarea prealabilă. Vă rugăm să aveți în vedere că programările se fac doar în cazul în care sunteți deja în posesia biletului de trimitere.</p>
                <p>Pentru informații privind efectuarea analizelor în baza biletului de trimitere CAS precum și disponibilitatea fondurilor, vă rugăm să contactați telefonic colegii din cel mai apropiat centru de analize ClinicMed, din lista de mai jos.</p>

                <h2 className="subtitle">Brașov</h2>
                <div className="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Centru</th>
                                <th>Adresă</th>
                                <th>Telefon</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>ClinicMed Brașov Vlahuță</td>
                                <td>Bd. Alexandru Vlahuță, nr. 42, bl. 121 (parter)</td>
                                <td>0268 585 965</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Brașov</td>
                                <td>Str. Stadionului nr.2 (Complex Bartolomeu, vis-a-vis de Gara Bartolomeu)</td>
                                <td>0268 510 476</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Uranus</td>
                                <td>Str. Uranus, nr. 3</td>
                                <td>0268 586 042</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Brașov Gloriei</td>
                                <td>Str. Gloriei, nr.11,BL 317</td>
                                <td>0368 404 221</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Codlea</td>
                                <td>Str. Lungă, nr. 117</td>
                                <td>0268 253 334</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Făgăraș</td>
                                <td>Str. Vasile Alescandri, Bl. 7, Sc. D</td>
                                <td>0368 404 328</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Râșnov</td>
                                <td>Piata Unirii, nr. 1</td>
                                <td>0268 231 777</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Rupea</td>
                                <td>Str. Republicii, nr. 112</td>
                                <td>0268 260 012</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Săcele</td>
                                <td>Piata Libertății, nr. 38</td>
                                <td>0368 404 010</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                {/* Repetă pentru celelalte locații */}
                
                <h2 className="subtitle">Bucuresti</h2>
                <div className="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Centru</th>
                                <th>Adresă</th>
                                <th>Telefon</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>ClinicMed București Drumul Taberei</td>
                                <td>Str. Piața Drumul Taberei, nr. 44, Sector 6</td>
                                <td>031 436 25 72</td>
                            </tr>
                            <tr>
                                <td>ClinicMed București (Titulescu)</td>
                                <td>Str. Nicolae Titulescu, Nr. 39-49, Bl. 12, Et. P</td>
                                <td>031 405 10 35</td>
                            </tr>
                            <tr>
                                <td>ClinicMed București (Theodor Pallady)</td>
                                <td>B-dul Theodor Pallady, nr. 21, bl. P 1, Sector 3</td>
                                <td>0314 209 254</td>
                            </tr>
                            <tr>
                                <td>ClinicMed București (Calea Grivitei 206)</td>
                                <td>Str. Calea Grivitei, nr. 206, sector 1</td>
                                <td>0314 250 546</td>
                            </tr>
                            <tr>
                                <td>ClinicMed București (Regie)</td>
                                <td>Str. Economu Cezărescu, nr. 31.B, Sector 6</td>
                                <td>0314 240 111</td>
                            </tr>
                            <tr>
                                <td>ClinicMed București (Bd. Timișoara)</td>
                                <td>Bd. Timisoara, nr. 69, bl. C13, parter, Sector 6</td>
                                <td>0314 213 323</td>
                            </tr>
                            <tr>
                                <td>ClinicMed București (Ion Mihalache)</td>
                                <td>Bld. Ion Mihalache, nr. 45, Sector 1</td>
                                <td>0314 210 114</td>
                            </tr>
                            <tr>
                                <td>ClinicMed București Margeanului</td>
                                <td>Str Mărgeanului, nr 44, bl M113</td>
                                <td>0314 206 624</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                {/* Repetă pentru celelalte locații */}

                <h2 className="subtitle">Cluj</h2>
                <div className="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Centru</th>
                                <th>Adresă</th>
                                <th>Telefon</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>ClinicMed Cluj</td>
                                <td>Bd. 21 Decembrie, nr. 129, bl. L7, sc. IV, ap. 80</td>
                                <td>0364 882 287</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Câmpia Turzii</td>
                                <td>Strada Andrei Mureșanu Nr. 2</td>
                                <td>0364 730 007</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Cluj Cipariu</td>
                                <td>Piața Cipariu, nr. 9</td>
                                <td>0364 734 639</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Cluj Bucegi</td>
                                <td>Str. Bucegi, nr. 13-15</td>
                                <td>0364 808 589</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Cluj Pasteur</td>
                                <td>Str. Pasteur, nr. 52</td>
                                <td>0364 801 146</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Cluj</td>
                                <td>Calea Moților, nr. 21</td>
                                <td>0264 236 197</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                {/* Repetă pentru celelalte locații */}

                <h2 className="subtitle">Craiova</h2>
                <div className="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Centru</th>
                                <th>Adresă</th>
                                <th>Telefon</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>ClinicMed Craiova</td>
                                <td>Bd. Nicolae Titulescu, nr. 30</td>
                                <td>0251 591 720</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Craiova</td>
                                <td>Str. Vasile Alecsandri, nr. 46</td>
                                <td>0251 425 660</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Craiova</td>
                                <td>Bd. Oltenia, nr. 34</td>
                                <td>0351 430 940</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Craiova</td>
                                <td>Bd. 1 Mai, nr. 65, bl. 20, sc. 2 (parter)</td>
                                <td>0251 453 856</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                {/* Repetă pentru celelalte locații */}

                <h2 className="subtitle">Sibiu</h2>
                <div className="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Centru</th>
                                <th>Adresă</th>
                                <th>Telefon</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>ClinicMed Mediaș</td>
                                <td>Str. I. G. Duca, nr. 16, ap. 3</td>
                                <td>0369 421 097</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Mediaș Calafat</td>
                                <td>Str. Calafat nr. 1, bl. 24, sc. C, et. P, ap. 63</td>
                                <td>0369 415 433</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Sibiu</td>
                                <td>Str. Turnului, nr. 17</td>
                                <td>0269 250 435</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Sibiu</td>
                                <td>Str. Semaforului, nr. 11, Parter</td>
                                <td>0369 415 838</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Cisnădie</td>
                                <td>Str. Măgurii, nr.78</td>
                                <td>0371 485 217</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Sibiu</td>
                                <td>Piața Aurel Vlaicu, nr. 1, bl. V4 (parter)</td>
                                <td>0369 439 642</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                {/* Repetă pentru celelalte locații */}

                <h2 className="subtitle">Timiș</h2>
                <div className="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Centru</th>
                                <th>Adresă</th>
                                <th>Telefon</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>ClinicMed Deta</td>
                                <td>Str. Victoriei, nr. 24</td>
                                <td>0356 405 229</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Sânnicolau Mare</td>
                                <td>Str. Piața 30 Decembrie, nr. 7</td>
                                <td>0356 409 269</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Jimbolia</td>
                                <td>Str. Republicii, nr. 53, ap. 1A</td>
                                <td>0371 490 157</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Lugoj</td>
                                <td>Str. Cuza Vodă, nr. 2A</td>
                                <td>0356 800 526</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Timișoara (Pârvan)</td>
                                <td>Str. Corneliu Coposu, nr. 12</td>
                                <td>0356 410 347</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Timișoara (Martirilor)</td>
                                <td>Calea Martirilor 1989, nr. 21, scara C</td>
                                <td>0356 178 050</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Timișoara (I. Văcărescu)</td>
                                <td>Strada Iancu Văcărescu Nr. 17</td>
                                <td>0356 409 476</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Timișoara</td>
                                <td>Calea Șagului Nr. 30-34, Parter</td>
                                <td>0356 178 344</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Timișoara</td>
                                <td>Calea Bogdăneștilor, nr. 6</td>
                                <td>0356 173 000</td>
                            </tr>
                            <tr>
                                <td>ClinicMed Timișoara</td>
                                <td>Calea Martirilor Nr. 1-3-5, Corp B, parter</td>
                                <td>0371 497 359</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default CentreCAS;
