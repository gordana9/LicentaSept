import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './AdminPage.css';

const AdminPage = () => {
    const [username, setUsername] = useState('');
    const [patients, setPatients] = useState([]); // State pentru pacienți
    const [specializations, setSpecializations] = useState([]); // State pentru specializări
    const [selectedSpecialization, setSelectedSpecialization] = useState(''); // State pentru specializarea selectată
    const [doctors, setDoctors] = useState([]); // State pentru doctori
    const navigate = useNavigate();

    useEffect(() => {
        const storedUsername = localStorage.getItem('username');
        if (storedUsername) {
            setUsername(storedUsername);
        }

        // Preluare lista pacienți la montarea componentei
        const fetchPatients = async () => {
            try {
                const response = await fetch('http://localhost:5000/get-patients');
                if (response.ok) {
                    const data = await response.json();
                    console.log('Pacienți primiți în frontend:', data); // Verificăm datele pacienților în frontend
                    setPatients(data); // Setarea listei de pacienți în state
                } else {
                    console.error('Failed to fetch patients: ', response.statusText);
                }
            } catch (error) {
                console.error('Error fetching patients:', error);
            }
        };

        // Preluare lista specializări la montarea componentei
        const fetchSpecializations = async () => {
            try {
                const response = await fetch('http://localhost:5000/specializations');
                if (response.ok) {
                    const data = await response.json();
                    console.log('Specializări:', data); // Verificăm datele specializărilor în frontend
                    setSpecializations(data); // Setarea listei de specializări în state
                } else {
                    console.error('Failed to fetch specializations: ', response.statusText);
                }
            } catch (error) {
                console.error('Error fetching specializations:', error);
            }
        };

        fetchPatients();
        fetchSpecializations();
    }, []);

    const handleLogout = () => {
        localStorage.removeItem('username');
        navigate('/login');
    };

    // Funcție pentru gestionarea selectării unei specializări și preluarea doctorilor
    const handleSpecializationChange = async (e) => {
        const specialization = e.target.value;
        setSelectedSpecialization(specialization);
        if (specialization) {
            try {
                const response = await fetch(`http://localhost:5000/doctors?specialization=${encodeURIComponent(specialization)}`);
                if (response.ok) {
                    const data = await response.json();
                    console.log('Doctors primiți în frontend:', data); // Verificăm datele doctorilor în frontend
                    setDoctors(data); // Setarea listei de doctori în state
                } else {
                    console.error('Failed to fetch doctors: ', response.statusText);
                }
            } catch (error) {
                console.error('Error fetching doctors:', error);
            }
        } else {
            setDoctors([]); // Resetează lista de doctori dacă nu este selectată nicio specializare
        }
    };

    return (
        <div className="admin-container">
            <div className="admin-sidebar">
                <h2>Bine ai venit, {username}!</h2>
                <ul>
                    {/* Sidebar links pot fi adăugate aici dacă sunt necesare */}
                </ul>
            </div>
            <div className="admin-content">
                {/* Afișarea listei de pacienți */}
                <div className="patients-list">
                    <h2>Lista Pacienților</h2>
                    {patients.length === 0 ? (
                        <p>Nu există pacienți înregistrați.</p>
                    ) : (
                        <ul>
                            {patients.map(patient => (
                                <li key={patient.PacientID}>
                                    {patient.Nume} {patient.Prenume} - Email: {patient.Email} - Varsta: {patient.Varsta} - CNP: {patient.CNP} - Telefon: {patient.NumarTelefon}
                                </li>
                            ))}
                        </ul>
                    )}
                </div>

                {/* Afișarea listei de specializări și doctori */}
                <div className="doctors-list">
                    <h2>Lista Doctorilor</h2>
                    <div className="select-specialization">
                        <label>Selectați specialitatea:</label>
                        <select value={selectedSpecialization} onChange={handleSpecializationChange}>
                            <option value="">Selectează o specialitate</option>
                            {specializations.map((specialization, index) => (
                                <option key={index} value={specialization}>{specialization}</option>
                            ))}
                        </select>
                    </div>
                    {doctors.length === 0 ? (
                        <p>Nu există doctori înregistrați pentru această specializare.</p>
                    ) : (
                        <ul>
                            {doctors.map(doctor => (
                                <li key={doctor.UserID}>
                                    {doctor.Nume} {doctor.Prenume} - Telefon: {doctor.NumarTelefon} - Email: {doctor.Email} - CNP: {doctor.CNP}
                                </li>
                            ))}
                        </ul>
                    )}
                </div>
            </div>
            <button className="logout-button" onClick={handleLogout}>Logout</button>
        </div>
    );
};

export default AdminPage;
