const express = require('express');
const cors = require('cors');
const sql = require('mssql');
const path = require('path');
const nodemailer = require('nodemailer'); // Adăugare Nodemailer pentru trimiterea de e-mailuri
const app = express();
const { poolPromise } = require('./db');

app.use(cors());
app.use(express.json());

// Serve static files from the React app
app.use(express.static(path.join(__dirname, '../my-react-app/build')));

let messages = {}; // Obiect pentru stocarea mesajelor

// Configurarea transportorului Nodemailer
const transporter = nodemailer.createTransport({
    service: 'gmail', // Poți schimba cu un alt serviciu sau configurare SMTP
    auth: {
        user: 'your-email@gmail.com', // Adresa de e-mail a expeditorului
        pass: 'your-email-password'   // Parola de aplicație (sau parola contului)
    }
});

// Funcție pentru trimiterea e-mailurilor de confirmare
const sendConfirmationEmail = (patientEmail, patientName, doctorName, date, time) => {
    const mailOptions = {
        from: 'your-email@gmail.com',
        to: patientEmail,
        subject: 'Confirmarea Programării la ClinicMed',
        text: `
            Bună ziua, ${patientName},

            Programarea dumneavoastră la ClinicMed a fost aprobată cu succes. Detaliile sunt următoarele:

            Doctor: Dr. ${doctorName}
            Data: ${date}
            Ora: ${time}

            Vă așteptăm cu drag,
            Echipa ClinicMed
        `
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error('Error sending confirmation email:', error);
        } else {
            console.log('Confirmation email sent:', info.response);
        }
    });
};

// Endpoint pentru aprobare programare
app.post('/approve-appointment', async (req, res) => {
    const { appointmentId } = req.body;

    try {
        const pool = await poolPromise;

        // Obținerea detaliilor programării din baza de date
        const result = await pool.request()
            .input('appointmentId', sql.Int, appointmentId)
            .query('SELECT a.*, p.Email AS patientEmail, p.Nume AS patientName, d.Nume AS doctorName FROM dbo.Appointments a JOIN dbo.Pacienti p ON a.PacientID = p.PacientID JOIN dbo.Doctori d ON a.DoctorID = d.UserID WHERE a.AppointmentID = @appointmentId');

        if (result.recordset.length === 0) {
            return res.status(404).json({ message: 'Programarea nu a fost găsită.' });
        }

        const appointment = result.recordset[0];
        const { patientEmail, patientName, doctorName, Date: date, Time: time } = appointment;

        // Actualizarea statusului programării la 'Approved'
        await pool.request()
            .input('appointmentId', sql.Int, appointmentId)
            .query('UPDATE dbo.Appointments SET Status = \'Approved\' WHERE AppointmentID = @appointmentId');

        // Trimiterea e-mailului de confirmare
        sendConfirmationEmail(patientEmail, patientName, doctorName, date, time);

        res.status(200).json({ message: 'Programarea a fost aprobată și e-mailul de confirmare a fost trimis.' });
    } catch (err) {
        console.error('Error during appointment approval:', err);
        res.status(500).json({ message: 'An error occurred. Please try again.' });
    }
});

// Endpoint pentru login
app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    console.log('Login request received with username:', username); // Log pentru cererea de login
    try {
        const pool = await poolPromise;
        const result = await pool.request()
            .input('username', sql.NVarChar, username)
            .input('password', sql.NVarChar, password)
            .query('SELECT * FROM dbo.Users WHERE Username = @username AND Password = @password');

        console.log('Login result:', result.recordset);

        if (result.recordset.length > 0) {
            const user = result.recordset[0];
            res.json({ userId: user.userID, userType: user.UserType });
        } else {
            res.status(401).json({ message: 'Invalid username or password' });
        }
    } catch (err) {
        console.error('Error during login:', err);
        res.status(500).json({ message: 'An error occurred. Please try again.' });
    }
});


// Endpoint pentru signup
app.post('/signup', async (req, res) => {
    const { username, password, nume, prenume, varsta, cnp, adresa, numarTelefon, email } = req.body;

    if (!username || !password || !email) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    try {
        const pool = await poolPromise;

        // Generarea automată a UserID
        const userIdResult = await pool.request()
            .query('SELECT ISNULL(MAX(UserID), 0) + 1 AS NewUserID FROM dbo.Users');
        const userId = userIdResult.recordset[0].NewUserID;
        console.log('Generated UserID:', userId); // Log pentru UserID

        // Generarea automată a PacientID
        const pacientIdResult = await pool.request()
            .query('SELECT ISNULL(MAX(PacientID), 0) + 1 AS NewPacientID FROM dbo.Pacienti');
        const pacientId = pacientIdResult.recordset[0].NewPacientID;
        console.log('Generated PacientID:', pacientId); // Log pentru PacientID

        // Verificare generare UserID și PacientID
        if (!userId || !pacientId) {
            console.error('UserID or PacientID generation failed');
            return res.status(500).json({ message: 'UserID or PacientID generation failed' });
        }

        // Adăugarea în tabelul Users
        await pool.request()
            .input('UserID', sql.Int, userId)
            .input('Username', sql.NVarChar, username)
            .input('Password', sql.NVarChar, password)
            .input('UserType', sql.NVarChar, 'Pacienti')
            .query('INSERT INTO dbo.Users (UserID, Username, Password, UserType) VALUES (@UserID, @Username, @Password, @UserType)');
        console.log('Inserted into Users table'); // Log pentru inserția în Users

        // Adăugarea în tabelul Pacienti
        const pacientInsertResult = await pool.request()
            .input('PacientID', sql.Int, pacientId)
            .input('UserID', sql.Int, userId)
            .input('Nume', sql.NVarChar, nume)
            .input('Prenume', sql.NVarChar, prenume)
            .input('Varsta', sql.Int, varsta)
            .input('CNP', sql.NVarChar, cnp)
            //.input('Adresa', sql.NVarChar, adresa)
            .input('NumarTelefon', sql.NVarChar, numarTelefon)
            .input('Email', sql.NVarChar, email)
            .query('INSERT INTO dbo.Pacienti (PacientID, UserID, Nume, Prenume, Varsta, CNP, Adresa, NumarTelefon, Email) VALUES (@PacientID, @UserID, @Nume, @Prenume, @Varsta, @CNP, @Adresa, @NumarTelefon, @Email)');
        console.log('Inserted into Pacienti table', pacientInsertResult); // Log pentru inserția în Pacienti

        res.status(201).json({ message: 'Pacient created successfully' });
    } catch (err) {
        console.error('Error during signup: ', err);
        res.status(500).json({ message: 'An error occurred. Please try again.' });
    }
});

// Endpoint pentru adăugarea unui doctor
app.post('/add-doctor', async (req, res) => {
    const { name, email, specialty, cnp, numarTelefon } = req.body;
    console.log('Add doctor request received:', req.body); // Log pentru cererea de adăugare doctor

    if (!name || !email || !specialty || !cnp || !numarTelefon) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    try {
        const pool = await poolPromise;

        const userIdResult = await pool.request()
            .query('SELECT ISNULL(MAX(UserID), 0) + 1 AS NewUserID FROM dbo.Users');
        const userId = userIdResult.recordset[0].NewUserID;

        await pool.request()
            .input('UserID', sql.Int, userId)
            .input('Username', sql.NVarChar, email) // Folosim emailul ca username
            .input('Password', sql.NVarChar, 'defaultpassword') // Parolă implicită, de schimbat ulterior
            .input('UserType', sql.NVarChar, 'Doctor')
            .query('INSERT INTO dbo.Users (UserID, Username, Password, UserType) VALUES (@UserID, @Username, @Password, @UserType)');

        await pool.request()
            .input('UserID', sql.Int, userId)
            .input('Nume', sql.NVarChar, name.split(' ')[0])
            .input('Prenume', sql.NVarChar, name.split(' ')[1])
            .input('CNP', sql.NVarChar, cnp)
            .input('NumarTelefon', sql.NVarChar, numarTelefon)
            .input('Email', sql.NVarChar, email)
            .input('Specializare', sql.NVarChar, specialty)
            .query('INSERT INTO dbo.Doctori (UserID, Nume, Prenume, CNP, NumarTelefon, Email, Specializare) VALUES (@UserID, @Nume, @Prenume, @CNP, @NumarTelefon, @Email, @Specializare)');

        res.status(201).json({ message: 'Doctor created successfully' });
    } catch (err) {
        console.error('Error during add doctor:', err);
        res.status(500).json({ message: 'An error occurred. Please try again.' });
    }
});

// Endpoint pentru statistici
app.get('/stats', async (req, res) => {
    console.log('Stats request received'); // Log pentru cererea de statistici
    try {
        const pool = await poolPromise;

        const patientsCount = await pool.request()
            .query('SELECT COUNT(*) as count FROM dbo.Pacienti');
        console.log('Patients count:', patientsCount.recordset[0].count); // Log pentru numărul de pacienți

        const doctorsCount = await pool.request()
            .query('SELECT COUNT(*) as count FROM dbo.Doctori');
        console.log('Doctors count:', doctorsCount.recordset[0].count); // Log pentru numărul de doctori

        const appointmentsCount = await pool.request()
            .query('SELECT COUNT(*) as count FROM dbo.Appointments WHERE status = \'accepted\'');
        console.log('Appointments count:', appointmentsCount.recordset[0].count); // Log pentru numărul de programări

        res.json({
            patients: patientsCount.recordset[0].count,
            doctors: doctorsCount.recordset[0].count,
            appointments: appointmentsCount.recordset[0].count
        });
    } catch (err) {
        console.error('Error fetching stats:', err);
        res.status(500).json({ message: 'An error occurred. Please try again.' });
    }
});

// Endpoint pentru specializări
app.get('/specializations', async (req, res) => {
    console.log('Specializations request received'); // Log pentru cererea de specializări
    try {
        const pool = await poolPromise;
        const result = await pool.request()
            .query('SELECT DISTINCT Specializare FROM dbo.Doctori');

        console.log('Specializations fetched:', result.recordset); // Mesaj de log
        res.json(result.recordset.map(row => row.Specializare));
    } catch (err) {
        console.error('Error fetching specializations:', err); // Mesaj de eroare
        res.status(500).json({ message: 'An error occurred. Please try again.' });
    }
});

// Endpoint pentru obținerea doctorilor
app.get('/doctors', async (req, res) => {
    const specialization = req.query.specialization;
    console.log('Doctors request received for specialization:', specialization); // Log pentru cererea de doctori
    try {
        const pool = await poolPromise;
        const result = await pool.request()
            .input('specialization', sql.NVarChar, specialization)
            .query('SELECT UserID, Nume, Prenume, NumarTelefon, Email, CNP FROM dbo.Doctori WHERE Specializare = @specialization');

        console.log('Doctori fetched:', result.recordset); // Mesaj de log
        result.recordset.forEach(doctor => {
            console.log(`Doctor: ${doctor.Nume} ${doctor.Prenume}`);
            console.log(`Telefon: ${doctor.NumarTelefon}`);
            console.log(`Email: ${doctor.Email}`);
            //console.log(`CNP: ${doctor.CNP}`); // Asigură-te că CNP-ul este logat
        });

        res.json(result.recordset); // Trimiterea rezultatului la frontend
    } catch (err) {
        console.error('Error fetching doctors:', err); // Mesaj de eroare
        res.status(500).json({ message: 'An error occurred. Please try again.' });
    }
});


// Endpoint pentru trimiterea mesajelor
// Endpoint pentru trimiterea mesajelor
app.post('/sendMessage', (req, res) => {
    const { userId, patientName, message } = req.body; // Folosim userId direct
    console.log('Message request received with:', req.body);

    if (!userId || !patientName || !message) {
        console.error('Missing required fields for message');
        return res.status(400).json({ message: 'userId, patientName, and message are required' });
    }

    if (!messages[userId]) {
        messages[userId] = [];
    }

    messages[userId].push({
        patientName,
        message,
        timestamp: new Date()
    });

    res.status(200).json({ message: 'Mesaj trimis cu succes!' });
});


// Endpoint pentru preluarea mesajelor
app.get('/getMessages', (req, res) => {
    const userId = req.query.userId;

    if (!userId) {
        console.error('userId is undefined or null in getMessages request');
        return res.status(400).json({ message: 'userId is required' });
    }

    console.log('Get messages request received for userId:', userId);

    res.json(messages[userId] || []);
});



// The "catch-all" handler: for any request that doesn't
// match one above, send back React's index.html file.
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../my-react-app/build', 'index.html'));
});

const port = process.env.PORT || 5000;
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
// Endpoint pentru obținerea listei complete de pacienți
// Endpoint pentru obținerea listei complete de pacienți
app.get('/get-patients', async (req, res) => {
    try {

        const pool = await poolPromise;
        const result = await pool.request()
            .query('SELECT Nume, Prenume, Email, CNP, NumarTelefon, PacientID FROM dbo.Pacienti');

        console.log('Pacienți:', result.recordset); // Mesaj de log
        res.json(result.recordset);
    } catch (err) {
        console.error('Error fetching patients:', err);
        res.status(500).json({ message: 'An error occurred. Please try again.' });
    }
});

